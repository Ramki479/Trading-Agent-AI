#!/usr/bin/env node
/**
 * strategy-experiments.js — approval workflow + shadow testing + rollback for
 * persistent adaptive changes (Circuit Tier 2 equivalent, adapted).
 *
 * Every persistent adaptation (baseline threshold change, learned-gate
 * promotion, sizing change) enters:
 *
 *   PROPOSED → BACKTESTING → SHADOW → PENDING_APPROVAL → PROMOTED
 *                                     └→ REJECTED
 *   PROMOTED → (reflection grades it) → ROLLED_BACK on STRONGLY_NEGATIVE
 *
 * Validation is deterministic and data-driven over real closed trades:
 *   - BACKTESTING: candidate entry gates applied to history vs V1 baseline
 *     (win rate / expectancy / profit factor tolerances, min sample).
 *   - SHADOW: hypothetical replay — every closed trade in the shadow window
 *     is recorded with wouldPass, candidate stats compared again.
 *   - PENDING_APPROVAL → PROMOTED only when validation passed AND autoApply
 *     is enabled; otherwise the operator flips adaptive.autoApply in
 *     config.json (the dashboard is strictly read-only — no write endpoint).
 *
 * Promoted baseline changes create a strategy version (V1 → V1.1 → V1.2)
 * with a parent pointer; rollback restores the parent. The system never
 * touches safety controls (SL/TP/cooldown/position limit/paper-only).
 *
 * Persistence (all in the agent data dir, append-only + atomic writes):
 *   data/experiments.jsonl       lifecycle events
 *   data/approvals.jsonl         approval records
 *   data/shadow-trades.jsonl     hypothetical trade replay
 *   data/strategy-versions.json  version chain
 */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const perf = require('./performance-analyzer.js');
const gatesLib = require('./learned-gates.js');

const STATES = ['PROPOSED', 'BACKTESTING', 'SHADOW', 'PENDING_APPROVAL', 'PROMOTED', 'REJECTED', 'ROLLED_BACK'];

function file(dataDir, name) {
  return path.join(dataDir, name);
}
function appendLine(filePath, obj) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.appendFileSync(filePath, JSON.stringify(obj) + '\n');
}
function readLines(filePath) {
  try {
    if (!fs.existsSync(filePath)) return [];
    return fs.readFileSync(filePath, 'utf8').split('\n').filter(Boolean)
      .map((l) => { try { return JSON.parse(l); } catch (_) { return null; } })
      .filter(Boolean);
  } catch (_) { return []; }
}

function nextId(prefix) {
  return prefix + '_' + crypto.randomBytes(6).toString('hex');
}

/* ------------------------------------------------------------------ *
 * Strategy version chain (data/strategy-versions.json).
 * ------------------------------------------------------------------ */

function versionFile(dataDir) { return file(dataDir, 'strategy-versions.json'); }

function defaultVersions(cfg) {
  const maxPositions = cfg.maxPositions || 3;
  return {
    current: 'V1',
    versions: [{
      id: 'V1',
      parentId: null,
      experimentId: null,
      deltas: { minScoreBase: 60, maxBuysBase: maxPositions, recoverySizeMultiplier: 0.5 },
      createdAt: new Date().toISOString(),
      status: 'active'
    }]
  };
}

function loadVersions(dataDir, cfg = {}) {
  try {
    const f = versionFile(dataDir);
    if (fs.existsSync(f)) {
      const v = JSON.parse(fs.readFileSync(f, 'utf8'));
      if (v && v.current && Array.isArray(v.versions) && v.versions.length) return v;
    }
  } catch (_) { /* corrupt → rebuild */ }
  return defaultVersions(cfg);
}

function saveVersions(dataDir, versions) {
  try {
    fs.mkdirSync(dataDir, { recursive: true });
    const f = versionFile(dataDir);
    const tmp = f + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(versions, null, 2) + '\n');
    fs.renameSync(tmp, f);
  } catch (_) { /* best effort */ }
}

function currentVersion(versions) {
  return (versions.versions || []).find((v) => v.id === versions.current) || (versions.versions || [])[0];
}

function nextVersionId(versions) {
  const base = 'V1';
  let n = 0;
  for (const v of (versions.versions || [])) {
    const m = /^V1\.(\d+)$/.exec(v.id);
    if (m) n = Math.max(n, parseInt(m[1], 10));
  }
  return base + '.' + (n + 1);
}

/** Effective persistent baseline from the current version (V1 floors + deltas). */
function effectiveBaseline(versions, cfg = {}) {
  const maxPositions = cfg.maxPositions || 3;
  const cur = currentVersion(versions) || {};
  const d = cur.deltas || {};
  return {
    minScoreBase: Math.max(60, Math.min(90, Number(d.minScoreBase) || 60)),
    maxBuysBase: Math.max(1, Math.min(maxPositions, Number(d.maxBuysBase) || maxPositions)),
    recoverySizeMultiplier: Math.max(0, Math.min(1, Number(d.recoverySizeMultiplier) != null ? Number(d.recoverySizeMultiplier) : 0.5)),
    versionId: cur.id || 'V1'
  };
}

/* ------------------------------------------------------------------ *
 * Experiments (data/experiments.jsonl — append-only event log).
 * ------------------------------------------------------------------ */

function loadExperiments(dataDir) {
  const events = readLines(file(dataDir, 'experiments.jsonl'));
  const byId = new Map();
  for (const e of events) {
    const key = e.experimentId || e.id;
    byId.set(key, Object.assign(byId.get(key) || {}, e));
  }
  return Array.from(byId.values());
}

function getExperiment(dataDir, id) {
  return loadExperiments(dataDir).find((e) => e.id === id) || null;
}

function transition(dataDir, id, patch) {
  const event = Object.assign({ experimentId: id, ts: new Date().toISOString() }, patch);
  appendLine(file(dataDir, 'experiments.jsonl'), event);
  return event;
}

/* ------------------------------------------------------------------ *
 * Approvals (data/approvals.jsonl — append-only).
 * ------------------------------------------------------------------ */

function submitApproval(dataDir, experiment, cfg = {}) {
  const rec = {
    id: nextId('appr'),
    experimentId: experiment.id,
    timestamp: new Date().toISOString(),
    title: `${experiment.type}: ${experiment.parameter} ${experiment.oldValue} → ${experiment.newValue}`,
    action: experiment.reason || '',
    priority: experiment.priority || 'MEDIUM',
    expectedLift: experiment.expectedLift || '',
    type: experiment.type,
    data: { parameter: experiment.parameter, oldValue: experiment.oldValue, newValue: experiment.newValue, evidence: experiment.evidence },
    status: 'pending',
    operatorNote: '',
    decidedAt: null,
    appliedAt: null
  };
  appendLine(file(dataDir, 'approvals.jsonl'), rec);
  return rec.id;
}

function loadApprovals(dataDir) {
  return readLines(file(dataDir, 'approvals.jsonl'));
}

function pendingApprovals(dataDir) {
  return loadApprovals(dataDir).filter((a) => a.status === 'pending')
    .sort((a, b) => {
      const pm = { HIGH: 3, MEDIUM: 2, LOW: 1 };
      return (pm[b.priority] || 0) - (pm[a.priority] || 0);
    });
}

function updateApproval(dataDir, experimentId, patch) {
  const path_ = file(dataDir, 'approvals.jsonl');
  const lines = readLines(path_);
  const updated = lines.map((a) => (a.experimentId === experimentId ? Object.assign({}, a, patch, { decidedAt: a.decidedAt || new Date().toISOString() }) : a));
  try {
    fs.writeFileSync(path_, updated.map((a) => JSON.stringify(a)).join('\n') + (updated.length ? '\n' : ''));
  } catch (_) { /* best effort */ }
}

/* ------------------------------------------------------------------ *
 * Backtest — candidate entry gates vs V1 over closed trades (in-sample).
 * ------------------------------------------------------------------ */

const DEFAULT_TOLERANCES = { winRatePts: 5, expectancyPct: 1.0, profitFactor: 0.2 };

function gateValueOf(trade, parameter) {
  if (parameter === 'minScore') return trade.entryScore;
  if (parameter === 'min1h' || parameter === 'max1h') return trade.change1hPct;
  if (parameter === 'min5m' || parameter === 'max5m') return trade.recovery5mPct;
  return null;
}

function passesGate(trade, parameter, value, v1 = gatesLib.V1) {
  const gates = Object.assign({}, v1, { [parameter]: value });
  const score = trade.entryScore == null ? v1.minScore : trade.entryScore;
  if (score < gates.minScore) return false;
  if (trade.change1hPct != null && (trade.change1hPct <= gates.min1h || trade.change1hPct > gates.max1h)) return false;
  if (trade.recovery5mPct != null && (trade.recovery5mPct < gates.min5m || trade.recovery5mPct > gates.max5m)) return false;
  return true;
}

/** Statistics over closed trades (subset). */
function statsOf(trades) {
  const m = perf.computeMetrics(trades);
  return {
    n: m.n, wins: m.wins, losses: m.losses, winRate: m.winRate,
    expectancyPct: m.expectancyPct, expectancySol: m.expectancySol,
    profitFactor: m.profitFactor, totalPnlSol: m.totalPnlSol
  };
}

/**
 * Run the backtest for a proposed gate change. Non-gate parameters (sizing,
 * mode, maxBuys) pass through with bounds validation only (they do not filter
 * entries, so win-rate backtests don't apply — documented in the evidence).
 */
function runBacktest(dataDir, experiment, closedTrades, cfg = {}) {
  if (typeof experiment === 'string') experiment = getExperiment(dataDir, experiment);
  if (!experiment) return { state: 'REJECTED', reason: 'unknown experiment' };
  transition(dataDir, experiment.id, { state: 'BACKTESTING', backtestStartedAt: new Date().toISOString() });

  const minTrades = cfg.backtestMinTrades || 5;
  const tolerances = Object.assign({}, DEFAULT_TOLERANCES, cfg.tolerances || {});
  const result = { state: 'BACKTESTING', startedAt: new Date().toISOString() };

  const baselineTrades = (Array.isArray(closedTrades) ? closedTrades : []).filter((t) => passesGate(t, experiment.parameter, experiment.oldValue));
  result.baseline = statsOf(baselineTrades);

  if (experiment.parameter.startsWith('sizing') || ['mode', 'maxBuys'].includes(experiment.parameter)) {
    // Behavioral change — no entry-filter effect. Validate bounds only.
    const v = Number(experiment.newValue);
    const ok = Number.isFinite(v) && v >= 0 && (experiment.parameter.startsWith('sizing') ? v <= 1 : v <= (cfg.maxPositions || 3));
    result.passed = ok;
    result.candidate = result.baseline;
    result.reason = ok
      ? 'non-entry-gate parameter — bounds validated, no filter effect (conservative pass)'
      : 'invalid value for parameter bounds';
  } else {
    const candidateTrades = baselineTrades.filter((t) => passesGate(t, experiment.parameter, experiment.newValue));
    result.candidate = statsOf(candidateTrades);
    result.passed =
      result.candidate.n >= minTrades &&
      result.candidate.winRate >= result.baseline.winRate - tolerances.winRatePts &&
      result.candidate.expectancyPct >= result.baseline.expectancyPct - tolerances.expectancyPct &&
      result.candidate.profitFactor >= result.baseline.profitFactor - tolerances.profitFactor;
    result.reason = result.passed
      ? `backtest passed (n=${result.candidate.n}): WR ${result.candidate.winRate}% vs ${result.baseline.winRate}%, exp ${result.candidate.expectancyPct}% vs ${result.baseline.expectancyPct}%`
      : `backtest failed (n=${result.candidate.n}): WR ${result.candidate.winRate}% vs ${result.baseline.winRate}%, exp ${result.candidate.expectancyPct}% vs ${result.baseline.expectancyPct}%`;
  }

  const next = result.passed ? 'SHADOW' : 'REJECTED';
  transition(dataDir, experiment.id, { state: next, backtest: result, backtestedAt: new Date().toISOString() });
  return Object.assign(result, { state: next });
}

/* ------------------------------------------------------------------ *
 * Shadow — hypothetical replay of closed trades under the candidate policy.
 * ------------------------------------------------------------------ */

/**
 * Evaluate an experiment in SHADOW over the closed trades that exited after
 * the shadow started. Records every window trade to data/shadow-trades.jsonl
 * (wouldPass + outcome). Needs minShadowTrades trades to decide; otherwise it
 * keeps shadowing.
 */
function evaluateShadow(dataDir, experiment, closedTrades, cfg = {}) {
  if (typeof experiment === 'string') experiment = getExperiment(dataDir, experiment);
  if (!experiment) return { state: 'REJECTED', reason: 'unknown experiment' };
  const minTrades = cfg.shadowMinTrades || 5;
  const tolerances = Object.assign({}, DEFAULT_TOLERANCES, cfg.tolerances || {});
  const startedAt = (experiment.shadow && experiment.shadow.startedAt)
    ? Date.parse(experiment.shadow.startedAt)
    : Date.parse(experiment.backtestStartedAt || experiment.createdAt || 0) || 0;

  const window = (Array.isArray(closedTrades) ? closedTrades : []).filter((t) => t.exitTs >= startedAt);

  // Append the hypothetical replay rows (audit trail).
  for (const t of window) {
    appendLine(file(dataDir, 'shadow-trades.jsonl'), {
      experimentId: experiment.id,
      ts: new Date().toISOString(),
      mint: t.mint,
      symbol: t.symbol,
      entryTs: t.entryTs,
      exitTs: t.exitTs,
      realizedPnlSol: t.realizedPnlSol,
      realizedPnlPct: t.realizedPnlPct,
      wouldPass: passesGate(t, experiment.parameter, experiment.newValue),
      entryScore: t.entryScore,
      change1hPct: t.change1hPct,
      recovery5mPct: t.recovery5mPct
    });
  }

  if (window.length < minTrades) {
    transition(dataDir, experiment.id, { shadow: { startedAt: experiment.shadow && experiment.shadow.startedAt, windowTrades: window.length, pending: true } });
    return { state: 'SHADOW', pending: true, windowTrades: window.length, needed: minTrades };
  }

  const baselineTrades = window.filter((t) => passesGate(t, experiment.parameter, experiment.oldValue));
  const candidateTrades = baselineTrades.filter((t) => passesGate(t, experiment.parameter, experiment.newValue));
  const baseline = statsOf(baselineTrades);
  const candidate = statsOf(candidateTrades);

  const passed =
    candidate.n >= minTrades &&
    candidate.winRate >= baseline.winRate - tolerances.winRatePts &&
    candidate.expectancyPct >= baseline.expectancyPct - tolerances.expectancyPct &&
    candidate.profitFactor >= baseline.profitFactor - tolerances.profitFactor;

  const evalResult = {
    state: 'SHADOW',
    evaluatedAt: new Date().toISOString(),
    windowTrades: window.length,
    baseline,
    candidate,
    passed
  };
  transition(dataDir, experiment.id, { shadow: evalResult });

  if (!passed) {
    rejectExperiment(dataDir, experiment.id, `shadow validation failed (WR ${candidate.winRate}% vs ${baseline.winRate}%)`);
    return Object.assign({}, evalResult, { state: 'REJECTED' });
  }

  // Validation passed → next step depends on autoApply.
  const autoApply = cfg.autoApply === true;
  if (autoApply) {
    return applyExperiment(dataDir, experiment.id, { via: 'autoApply', note: 'shadow validation passed and adaptive.autoApply enabled' });
  }
  transition(dataDir, experiment.id, { state: 'PENDING_APPROVAL', approvalRequestedAt: new Date().toISOString() });
  return Object.assign({}, evalResult, { state: 'PENDING_APPROVAL' });
}

/* ------------------------------------------------------------------ *
 * Create / approve / reject / apply / rollback.
 * ------------------------------------------------------------------ */

function createExperiment(dataDir, opts = {}) {
  const parameter = String(opts.parameter || '');
  const oldValue = opts.oldValue;
  const newValue = opts.newValue;
  const id = nextId('exp');
  const experiment = {
    id,
    type: opts.type || 'policy',
    parameter,
    oldValue,
    newValue,
    reason: opts.reason || '',
    evidence: opts.evidence || {},
    priority: opts.priority || 'MEDIUM',
    expectedLift: opts.expectedLift || '',
    state: 'PROPOSED',
    createdAt: new Date().toISOString(),
    parentVersion: opts.parentVersion || null,
    autoApply: opts.autoApply === true
  };
  appendLine(file(dataDir, 'experiments.jsonl'), Object.assign({}, experiment, { experimentId: id, event: 'created' }));
  const approvalId = submitApproval(dataDir, experiment, opts.cfg || {});
  transition(dataDir, id, { approvalId });
  return Object.assign({}, experiment, { approvalId });
}

function approveExperiment(dataDir, id, { note = '', operator = 'operator' } = {}) {
  const exp = getExperiment(dataDir, id);
  if (!exp) return null;
  if (exp.state !== 'PENDING_APPROVAL') return { error: `cannot approve experiment in state ${exp.state}` };
  return applyExperiment(dataDir, id, { via: 'operator', note, operator });
}

function rejectExperiment(dataDir, id, note = '') {
  const exp = getExperiment(dataDir, id);
  if (!exp) return null;
  transition(dataDir, id, { state: 'REJECTED', rejectedAt: new Date().toISOString(), rejectionNote: note });
  updateApproval(dataDir, id, { status: 'rejected', operatorNote: note });
  return getExperiment(dataDir, id);
}

function applyExperiment(dataDir, id, { via = 'autoApply', note = '', operator = null } = {}) {
  const exp = getExperiment(dataDir, id);
  if (!exp) return null;
  if (!['PENDING_APPROVAL', 'SHADOW'].includes(exp.state)) {
    return { error: `cannot apply experiment in state ${exp.state}` };
  }

  const versions = loadVersions(dataDir);
  const cur = currentVersion(versions);
  let targetVersion = cur.id;
  let revert = null;

  if (exp.type === 'gate-update') {
    // Promote the learned gate into learned-gates.json for its cluster.
    const gates = gatesLib.loadGates(dataDir);
    if (!gates.gates[exp.evidence.clusterKey]) gates.gates[exp.evidence.clusterKey] = {};
    gates.gates[exp.evidence.clusterKey][exp.parameter] = {
      oldValue: exp.oldValue,
      newValue: exp.newValue,
      confidence: exp.evidence.confidence,
      sample: exp.evidence.sample,
      reasoning: exp.reason,
      promotedAt: new Date().toISOString()
    };
    gatesLib.saveGates(dataDir, gates.gates);
    revert = { kind: 'gate', clusterKey: exp.evidence.clusterKey, parameter: exp.parameter };
  } else if (exp.type === 'baseline') {
    // Baseline change → new strategy version with parent pointer.
    const id2 = nextVersionId(versions);
    const d = Object.assign({}, cur.deltas || {});
    d[exp.parameter] = Number(exp.newValue);
    versions.versions.push({
      id: id2,
      parentId: cur.id,
      experimentId: exp.id,
      deltas: d,
      createdAt: new Date().toISOString(),
      status: 'active'
    });
    versions.current = id2;
    saveVersions(dataDir, versions);
    targetVersion = id2;
    revert = { kind: 'baseline', parameter: exp.parameter, parentId: cur.id };
  } else {
    return { error: `unsupported experiment type ${exp.type}` };
  }

  transition(dataDir, id, {
    state: 'PROMOTED',
    promotedAt: new Date().toISOString(),
    promotedVia: via,
    targetVersion,
    revert
  });
  updateApproval(dataDir, id, { status: 'applied', operatorNote: note + (operator ? ` (by ${operator})` : ''), appliedAt: new Date().toISOString() });
  // Record the change for later grading (reflection-engine reads this log).
  // Lazy require — strategy-experiments and reflection-engine reference each
  // other at runtime only, so no circular-load problem.
  try {
    require('./reflection-engine.js').logPolicyChange(dataDir, {
      policyChangeId: exp.id,
      strategyVersion: targetVersion,
      parameter: exp.parameter,
      oldValue: exp.oldValue,
      newValue: exp.newValue,
      reason: exp.reason,
      evidence: exp.evidence
    });
  } catch (_) { /* best effort */ }
  return getExperiment(dataDir, id);
}

/**
 * Roll back a promoted experiment that performed materially worse.
 * Restores the parent version (baseline changes) or removes the gate
 * (gate updates). Never touches safety controls.
 */
function rollbackExperiment(dataDir, id, { grade = 'NEGATIVE', note = '' } = {}) {
  const exp = getExperiment(dataDir, id);
  if (!exp) return null;
  if (exp.state !== 'PROMOTED') return { error: `cannot roll back experiment in state ${exp.state}` };

  const versions = loadVersions(dataDir);
  const cur = currentVersion(versions);
  const revert = exp.revert || {};

  if (revert.kind === 'gate' && revert.clusterKey && revert.parameter) {
    const gates = gatesLib.loadGates(dataDir);
    if (gates.gates[revert.clusterKey]) {
      delete gates.gates[revert.clusterKey][revert.parameter];
      if (!Object.keys(gates.gates[revert.clusterKey]).length) delete gates.gates[revert.clusterKey];
      gatesLib.saveGates(dataDir, gates.gates);
    }
  } else if (revert.kind === 'baseline' && revert.parentId) {
    const parent = (versions.versions || []).find((v) => v.id === revert.parentId);
    if (parent) {
      versions.current = parent.id;
      saveVersions(dataDir, versions);
    }
  }

  transition(dataDir, id, { state: 'ROLLED_BACK', rolledBackAt: new Date().toISOString(), rollbackGrade: grade, rollbackNote: note });
  updateApproval(dataDir, id, { status: 'rolled_back', operatorNote: note });
  return getExperiment(dataDir, id);
}

/* ------------------------------------------------------------------ *
 * Summary for the dashboard.
 * ------------------------------------------------------------------ */

function summary(dataDir, cfg = {}) {
  const experiments = loadExperiments(dataDir);
  const versions = loadVersions(dataDir);
  const approvals = loadApprovals(dataDir);
  const baseline = effectiveBaseline(versions, cfg);
  const gates = gatesLib.gateSummary(gatesLib.loadGates(dataDir));
  return {
    versions: { current: versions.current, list: versions.versions },
    baseline,
    experiments: {
      total: experiments.length,
      byState: STATES.reduce((acc, s) => { acc[s] = experiments.filter((e) => e.state === s).length; return acc; }, {}),
      recent: experiments.slice(-8).map((e) => ({
        id: e.id,
        type: e.type,
        parameter: e.parameter,
        oldValue: e.oldValue,
        newValue: e.newValue,
        state: e.state,
        createdAt: e.createdAt,
        reason: e.reason
      }))
    },
    approvals: {
      pending: approvals.filter((a) => a.status === 'pending').length,
      approved: approvals.filter((a) => a.status === 'approved' || a.status === 'applied').length,
      rejected: approvals.filter((a) => a.status === 'rejected').length,
      rolledBack: approvals.filter((a) => a.status === 'rolled_back').length,
      pendingList: pendingApprovals(dataDir)
    },
    gates: {
      clusters: gates.clusters,
      entries: gates.entries,
      updatedAt: gates.updatedAt,
      list: gates.clustersList
    },
    rollback: {
      rolledBackExperiments: experiments.filter((e) => e.state === 'ROLLED_BACK').length
    }
  };
}

module.exports = {
  STATES,
  createExperiment,
  getExperiment,
  loadExperiments,
  runBacktest,
  evaluateShadow,
  approveExperiment,
  rejectExperiment,
  applyExperiment,
  rollbackExperiment,
  loadVersions,
  saveVersions,
  currentVersion,
  nextVersionId,
  effectiveBaseline,
  loadApprovals,
  pendingApprovals,
  submitApproval,
  summary,
  passesGate,
  statsOf
};