#!/usr/bin/env node
/**
 * regime-detector.js — deterministic, data-driven market regime detection for
 * the paper trader (Circuit Tier 1 equivalent).
 *
 * Modeled on upstream `lib/analysis/regime-state.js` (verified): the same
 * four regimes (bull / consolidation / recovery / dump) plus an explicit
 * UNKNOWN that safely falls back to the V1 baseline. Classification is
 * deterministic — win rate + average P&L over real closed trades in the last
 * 7 days — never an LLM guess and never Math.random().
 *
 * Regime state is persisted to data/regime-state.json with a TTL (default
 * 2 h, like upstream), consumed by:
 *   - adaptive-policy.js  (session mode / minScore / maxBuys)
 *   - the scanner         (entry sizing multiplier + buy gating)
 *   - reflection-engine.js (performance by regime)
 *
 * Safety: UNKNOWN or unreadable state → V1 behavior (active, 1.0× size).
 */

'use strict';

const fs = require('fs');
const path = require('path');

const REGIMES = ['bull', 'consolidation', 'recovery', 'dump', 'UNKNOWN'];
const DEFAULT_TTL_MS = 2 * 3600 * 1000; // upstream uses a 2h TTL
const MIN_REGIME_TRADES = 5;             // upstream: <5 recent trades → insufficient
const WEEK_MS = 7 * 24 * 3600 * 1000;

/* ------------------------------------------------------------------ *
 * Pure detection.
 * ------------------------------------------------------------------ */

/**
 * Classify the market regime from real closed trades (7d window).
 * @param {Array} trades closed trades from performance-analyzer.pairTrades()
 * @param {object} opts { nowMs, minTrades }
 * @returns {{ regime, confidence, reasoning, data }}
 */
function detectRegime(trades, opts = {}) {
  const now = opts.nowMs || Date.now();
  const minTrades = opts.minTrades || MIN_REGIME_TRADES;
  const list = Array.isArray(trades) ? trades : [];
  const recent = list.filter((t) => t.exitTs >= now - WEEK_MS);

  if (recent.length < minTrades) {
    return {
      regime: 'UNKNOWN',
      confidence: 0.1,
      reasoning: `Insufficient data: ${recent.length}/${minTrades} recent closed trades in 7d window — V1 baseline applies`,
      data: { windowTrades: recent.length, minTrades }
    };
  }

  const wins = recent.filter((t) => t.realizedPnlSol > 0).length;
  const winRate = wins / recent.length;
  const avgPnl = recent.reduce((s, t) => s + (t.realizedPnlPct || 0), 0) / recent.length;

  let regime = 'consolidation';
  let confidence = 0.5;
  let reasoning = '';

  if (winRate > 0.60 && avgPnl > 2.0) {
    regime = 'bull';
    confidence = Math.min(0.95, 0.5 + winRate * 0.3);
    reasoning = `Bull: ${(winRate * 100).toFixed(0)}% WR, avg ${avgPnl.toFixed(1)}% P&L`;
  } else if (winRate > 0.50 && avgPnl > 1.0) {
    regime = 'bull';
    confidence = 0.70;
    reasoning = `Mild bull: ${(winRate * 100).toFixed(0)}% WR`;
  } else if (winRate > 0.40 && avgPnl >= -1.0) {
    regime = 'consolidation';
    confidence = 0.60;
    reasoning = `Consolidation: ${(winRate * 100).toFixed(0)}% WR, near-zero avg`;
  } else if (winRate > 0.25 && avgPnl < -2.0) {
    regime = 'recovery';
    confidence = 0.60;
    reasoning = `Recovery: ${(winRate * 100).toFixed(0)}% WR but down ${avgPnl.toFixed(1)}%, likely bouncing`;
  } else if (winRate <= 0.25 || avgPnl < -3.0) {
    regime = 'dump';
    confidence = Math.min(0.95, Math.max(0.5, (1.0 - winRate) * 0.8));
    reasoning = `Dump: ${(winRate * 100).toFixed(0)}% WR, avg ${avgPnl.toFixed(1)}%`;
  } else {
    regime = 'consolidation';
    confidence = 0.50;
    reasoning = `Unclear: ${(winRate * 100).toFixed(0)}% WR, avg ${avgPnl.toFixed(1)}%`;
  }

  return {
    regime,
    confidence: Math.round(confidence * 100) / 100,
    reasoning,
    data: {
      windowTrades: recent.length,
      winRate: Math.round(winRate * 10000) / 100,
      avgPnlPct: Math.round(avgPnl * 100) / 100
    }
  };
}

/**
 * Regime → recommended session strategy (adapted from upstream
 * `strategyForRegime`, but never lowering the V1 score floor and never
 * exceeding the paper position cap).
 */
function strategyForRegime(regime, cfg = {}) {
  const maxPositions = cfg.maxPositions || 3;
  const strategies = {
    bull: {
      mode: 'active',
      minScore: 60,
      maxBuys: maxPositions,
      recommendation: 'Bull regime — V1 active mode, full capacity.'
    },
    consolidation: {
      mode: 'selective',
      minScore: 60,
      maxBuys: Math.max(1, Math.min(2, maxPositions)),
      recommendation: 'Consolidation — selective mode, top candidate only, capped entries.'
    },
    recovery: {
      mode: 'watchOnly',
      minScore: 60,
      maxBuys: 0,
      recommendation: 'Recovery regime — hold cash, watch only until re-entry signals improve.'
    },
    dump: {
      mode: 'watchOnly',
      minScore: 60,
      maxBuys: 0,
      recommendation: 'Dump regime — emergency hold, watch only until regime shifts.'
    },
    UNKNOWN: {
      mode: 'active',
      minScore: 60,
      maxBuys: maxPositions,
      recommendation: 'Unknown regime — V1 baseline active mode.'
    }
  };
  return strategies[regime] || strategies.UNKNOWN;
}

/**
 * Position-size multiplier for a regime. NEVER exceeds 1.0 in this paper
 * agent (the 0.05 SOL ceiling is a hard cap); dump → 0 (no entries).
 * Multipliers are configurable via cfg.sizing { bull, consolidation,
 * recovery, dump }. UNKNOWN → 1.0 (V1).
 */
function sizeMultiplierForRegime(regime, cfg = {}) {
  const sizing = (cfg.sizing && typeof cfg.sizing === 'object') ? cfg.sizing : {};
  const defaults = { bull: 1.0, consolidation: 1.0, recovery: 0.5, dump: 0.0 };
  const key = regime === 'UNKNOWN' ? 'consolidation' : regime;
  const m = Number(sizing[key]);
  if (!Number.isFinite(m)) return defaults[key] != null ? defaults[key] : 1.0;
  return Math.max(0, Math.min(2, m)); // clamped at module level; agentd enforces the 0.05 cap
}

/* ------------------------------------------------------------------ *
 * Persistence (data/regime-state.json, TTL'd like upstream).
 * ------------------------------------------------------------------ */

function regimeStateFile(dataDir) {
  return path.join(dataDir, 'regime-state.json');
}

const DEFAULT_STATE = {
  regime: 'UNKNOWN',
  confidence: 0.0,
  reasoning: 'No regime detected yet — V1 baseline',
  detectedAt: null,
  validUntil: null
};

function loadRegimeState(dataDir) {
  try {
    const file = regimeStateFile(dataDir);
    if (fs.existsSync(file)) {
      const state = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (state && state.regime) {
        if (state.validUntil && Date.now() < new Date(state.validUntil).getTime()) {
          return state;
        }
        // Expired → stale; caller treats it as UNKNOWN via fallback.
        return Object.assign({}, DEFAULT_STATE, state, { expired: true });
      }
    }
  } catch (_) { /* unreadable → default */ }
  return Object.assign({}, DEFAULT_STATE);
}

function saveRegimeState(dataDir, state, ttlMs = DEFAULT_TTL_MS) {
  const out = Object.assign({}, DEFAULT_STATE, state, {
    regime: REGIMES.includes(state && state.regime) ? state.regime : 'UNKNOWN',
    detectedAt: new Date().toISOString(),
    validUntil: new Date(Date.now() + ttlMs).toISOString()
  });
  try {
    fs.mkdirSync(dataDir, { recursive: true });
    const file = regimeStateFile(dataDir);
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(out, null, 2) + '\n');
    fs.renameSync(tmp, file);
  } catch (_) { /* best effort */ }
  return out;
}

/* ------------------------------------------------------------------ *
 * Convenience: full detect + persist in one call (used by the agent-loop).
 * ------------------------------------------------------------------ */

function detectAndSave(dataDir, trades, cfg = {}, opts = {}) {
  const detected = detectRegime(trades, opts);
  const saved = saveRegimeState(dataDir, {
    regime: detected.regime,
    confidence: detected.confidence,
    reasoning: detected.reasoning,
    data: detected.data
  }, opts.ttlMs || cfg.regimeTtlMs || DEFAULT_TTL_MS);
  return Object.assign({}, detected, { validUntil: saved.validUntil, detectedAt: saved.detectedAt });
}

module.exports = {
  REGIMES,
  DEFAULT_TTL_MS,
  MIN_REGIME_TRADES,
  detectRegime,
  strategyForRegime,
  sizeMultiplierForRegime,
  loadRegimeState,
  saveRegimeState,
  detectAndSave
};