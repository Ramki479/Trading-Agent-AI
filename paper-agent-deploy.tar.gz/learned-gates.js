#!/usr/bin/env node
/**
 * learned-gates.js — learn + apply adaptive entry thresholds (Circuit Tier 1
 * equivalent, adapted to this paper strategy).
 *
 * Upstream learns a buyRatio threshold per `pattern|timeOfDay|liquidityClass`
 * cluster (verified in lib/analysis/gate-learner.js + learned-gates.js). Our
 * V1 strategy gates on score / 1h change / 5m recovery instead, so we learn
 * the SAME MECHANISM over the thresholds V1 actually uses:
 *
 *   cluster  = regime | timeOfDay | liquidityClass
 *   gates    = minScore, min1h, max1h, min5m, max5m
 *
 * Learned gates can only be STRICTER than V1 (never looser):
 *   minScore ∈ [60, 90]      (V1 floor is preserved — score >= 60 always)
 *   min1h    ∈ [-35, -15]    (raise the 1h lower bound)
 *   max1h    ∈ [15, 5]       (lower the 1h upper bound)
 *   min5m    ∈ [0.25, 2]     (raise the 5m recovery floor)
 *   max5m    ∈ [8, 3]        (lower the 5m recovery ceiling)
 *
 * Minimum sample protection is mandatory: a cluster below MIN_SAMPLES learns
 * nothing and the scanner falls back to V1 (INSUFFICIENT_DATA).
 *
 * Persisted to data/learned-gates.json; only PROMOTED gates live in the file
 * (candidates travel through the strategy-experiments approval workflow).
 */

'use strict';

const fs = require('fs');
const path = require('path');

/* V1 baseline (must match agentd.js — do not change). */
const V1 = {
  minScore: 60,
  min1h: -35,
  max1h: 15,
  min5m: 0.25,
  max5m: 8
};

const GATE_PARAMS = ['minScore', 'min1h', 'max1h', 'min5m', 'max5m'];

/* Stricter-than-V1 bounds for each gate parameter. */
const BOUNDS = {
  minScore: { min: 60, max: 90, step: 5 },
  min1h: { min: -35, max: -15, step: 5 },   // higher = stricter
  max1h: { min: 5, max: 15, step: 5 },      // lower = stricter
  min5m: { min: 0.25, max: 2, step: 0.25 }, // higher = stricter
  max5m: { min: 3, max: 8, step: 1 }        // lower = stricter
};

const MIN_SAMPLES = 8;
const DEFAULT_CONFIDENCE_THRESHOLD = 0.85;

function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}

/** Cluster key: `regime|timeOfDay|liqClass` (regime defaults to 'unknown'). */
function clusterKeyOf({ regime, timeOfDay, liqClass }) {
  return [regime || 'unknown', timeOfDay || 'unknown', liqClass || 'medium'].join('|');
}

/** Does a closed trade pass V1 + a candidate gate value for one parameter? */
function passesWith(trade, param, value) {
  const gates = Object.assign({}, V1, { [param]: value });
  const score = trade.entryScore == null ? V1.minScore : trade.entryScore;
  if (score < gates.minScore) return false;
  const c1h = trade.change1hPct;
  if (c1h != null && (c1h <= gates.min1h || c1h > gates.max1h)) return false;
  const c5m = trade.recovery5mPct;
  if (c5m != null && (c5m < gates.min5m || c5m > gates.max5m)) return false;
  return true;
}

/** Score of a filtered subset: wins − losses×1.5 (same objective as upstream). */
function scoreSubset(trades) {
  let wins = 0, losses = 0;
  for (const t of trades) {
    if (t.realizedPnlSol > 0) wins += 1;
    else losses += 1;
  }
  return { wins, losses, score: wins - losses * 1.5 };
}

/**
 * Learn candidate gate updates per cluster from real closed trades.
 * Returns { proposals, perCluster } where proposals is an array of
 *   { clusterKey, parameter, oldValue, newValue, confidence, sample,
 *     wins, losses, reasoning }
 * Only clusters with sample >= minSamples produce proposals; a parameter is
 * proposed only when a stricter value strictly beats the V1 baseline score
 * for that cluster. Confidence rises with sample size (0.5 + 0.05×n, capped
 * 0.95) — matching upstream's n-based confidence.
 */
function learnGates(trades, opts = {}) {
  const minSamples = opts.minSamples || MIN_SAMPLES;
  const list = Array.isArray(trades) ? trades : [];
  const byCluster = new Map();
  for (const t of list) {
    const key = clusterKeyOf(t);
    if (!byCluster.has(key)) byCluster.set(key, []);
    byCluster.get(key).push(t);
  }

  const proposals = [];
  const perCluster = {};

  for (const [clusterKey, cluster] of byCluster) {
    if (cluster.length < minSamples) {
      perCluster[clusterKey] = {
        n: cluster.length,
        status: 'INSUFFICIENT_DATA',
        reason: `only ${cluster.length}/${minSamples} trades — V1 applies`
      };
      continue;
    }
    const baseline = scoreSubset(cluster);
    const entries = [];
    for (const param of GATE_PARAMS) {
      const b = BOUNDS[param];
      let bestValue = null;
      let best = null;
      for (let v = b.min; v <= b.max + 1e-9; v = Math.round((v + b.step) * 1000) / 1000) {
        const subset = cluster.filter((t) => passesWith(t, param, v));
        if (subset.length < Math.max(3, Math.round(minSamples * 0.3))) continue; // keep meaningful sample
        const s = scoreSubset(subset);
        if (!best || s.score > best.score) { best = s; bestValue = v; }
      }
      if (best && bestValue != null && best.score > baseline.score + 1e-9 && bestValue !== V1[param]) {
        entries.push({
          clusterKey,
          parameter: param,
          oldValue: V1[param],
          newValue: bestValue,
          confidence: Math.min(0.95, 0.5 + cluster.length * 0.05),
          sample: cluster.length,
          wins: best.wins,
          losses: best.losses,
          reasoning: `cluster ${clusterKey}: ${best.wins}W/${best.losses}L at ${param}=${bestValue} (vs V1 ${V1[param]}, baseline ${baseline.wins}W/${baseline.losses}L)`
        });
      }
    }
    perCluster[clusterKey] = {
      n: cluster.length,
      status: 'LEARNED',
      baseline: { wins: baseline.wins, losses: baseline.losses, score: Math.round(baseline.score * 10) / 10 },
      proposals: entries
    };
    proposals.push(...entries);
  }

  return { proposals, perCluster };
}

/* ------------------------------------------------------------------ *
 * Persistence (data/learned-gates.json) — only PROMOTED gates.
 * ------------------------------------------------------------------ */

function gatesFile(dataDir) {
  return path.join(dataDir, 'learned-gates.json');
}

function loadGates(dataDir) {
  try {
    const file = gatesFile(dataDir);
    if (fs.existsSync(file)) {
      const obj = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (obj && obj.gates && typeof obj.gates === 'object') return obj;
    }
  } catch (_) { /* unreadable → none */ }
  return { gates: {}, updatedAt: null };
}

function saveGates(dataDir, gates) {
  const out = { gates: gates || {}, updatedAt: new Date().toISOString() };
  try {
    fs.mkdirSync(dataDir, { recursive: true });
    const file = gatesFile(dataDir);
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(out, null, 2) + '\n');
    fs.renameSync(tmp, file);
  } catch (_) { /* best effort */ }
  return out;
}

/**
 * Effective entry gates for a candidate: V1 tightened by any PROMOTED learned
 * gate whose confidence clears the threshold. Never looser than V1.
 * @returns {{ minScore, min1h, max1h, min5m, max5m, applied: string[] }}
 */
function effectiveGates(gates, clusterKey, cfg = {}) {
  const threshold = cfg.gateConfidenceThreshold != null ? cfg.gateConfidenceThreshold : DEFAULT_CONFIDENCE_THRESHOLD;
  const eff = Object.assign({}, V1);
  const applied = [];
  const cluster = (gates && gates.gates && gates.gates[clusterKey]) || {};
  for (const param of GATE_PARAMS) {
    const g = cluster[param];
    if (!g) continue;
    const conf = Number(g.confidence);
    if (!Number.isFinite(conf) || conf < threshold) continue;
    const v = Number(g.newValue);
    if (!Number.isFinite(v)) continue;
    const b = BOUNDS[param];
    const clamped = clamp(v, b.min, b.max);
    // Stricter-only: minScore/min1h/min5m raise, max1h/max5m lower.
    const stricter = param === 'max1h' || param === 'max5m' ? clamped <= V1[param] : clamped >= V1[param];
    if (!stricter) continue;
    eff[param] = clamped;
    applied.push(`${param}=${clamped} (conf ${conf.toFixed(2)}, n=${g.sample})`);
  }
  return { gates: eff, applied };
}

/** Dashboard summary of promoted gates. */
function gateSummary(gates) {
  const g = (gates && gates.gates) || {};
  const out = { clusters: 0, entries: 0, updatedAt: gates && gates.updatedAt || null, clustersList: [] };
  for (const [key, entry] of Object.entries(g)) {
    const params = Object.keys(entry || {}).filter((p) => GATE_PARAMS.includes(p));
    if (!params.length) continue;
    out.clusters += 1;
    out.entries += params.length;
    out.clustersList.push({ clusterKey: key, gates: params.map((p) => ({ parameter: p, value: entry[p].newValue, confidence: entry[p].confidence, sample: entry[p].sample })) });
  }
  return out;
}

module.exports = {
  V1,
  GATE_PARAMS,
  BOUNDS,
  MIN_SAMPLES,
  DEFAULT_CONFIDENCE_THRESHOLD,
  clusterKeyOf,
  passesWith,
  scoreSubset,
  learnGates,
  loadGates,
  saveGates,
  effectiveGates,
  gateSummary
};