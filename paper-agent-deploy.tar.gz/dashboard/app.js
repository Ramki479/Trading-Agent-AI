/* Dashboard app — READ-ONLY frontend for the paper-portfolio API.
 *
 * Polls the API on CIRCUIT_POLL_MS. If the API is unreachable the page keeps
 * its last good data but clearly marks the connection OFFLINE / STALE — it
 * never pretends stale data is live, and it never writes anything anywhere.
 *
 * MONEY DISPLAY: the dashboard is displayed in Indian Rupees (₹). The API
 * attaches real INR mirror fields (equityInr, cashInr, …) derived from the
 * real SOL/USD price and a live USD/INR rate — never fake or hard-coded.
 * Original SOL/USD values remain visible as secondary text / tooltips, and
 * the page falls back to SOL when no rate is available. Trading logic is
 * untouched and remains 100% paper.
 */
'use strict';

(function () {
  // ---- resolve API base ----------------------------------------------
  const params = new URLSearchParams(window.location.search);
  const apiOverride = params.get('api');
  const SAME_ORIGIN = location.protocol === 'http:' || location.protocol === 'https:';
  const API_BASE = (apiOverride ||
    window.CIRCUIT_API_URL ||
    (SAME_ORIGIN ? '' : 'http://127.0.0.1:8787')).replace(/\/+$/, '');
  const POLL_MS = Math.max(1500, window.CIRCUIT_POLL_MS || 3000);

  // ---- tiny DOM helpers ----------------------------------------------
  const $ = (id) => document.getElementById(id);
  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  };
  const fmt = (n, d = 5) => (Number.isFinite(n) ? n.toFixed(d) : '—');
  const signed = (n, d = 5) => (Number.isFinite(n) ? (n >= 0 ? '+' : '') + n.toFixed(d) : '—');
  const signedPct = (n, d = 2) => (Number.isFinite(n) ? (n >= 0 ? '+' : '') + n.toFixed(d) + '%' : '—');
  const upDown = (n) => (Number.isFinite(n) ? (n > 0 ? 'up' : n < 0 ? 'down' : '') : '');
  const solMoney = (n) => fmt(n, 5) + ' SOL';
  const ago = (ts) => {
    if (!ts) return 'never';
    const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 5) return 'just now';
    if (s < 60) return s + 's ago';
    if (s < 3600) return Math.floor(s / 60) + 'm ' + (s % 60) + 's ago';
    return Math.floor(s / 3600) + 'h ' + Math.floor((s % 3600) / 60) + 'm ago';
  };
  const localTime = (iso) => {
    const t = new Date(iso);
    return Number.isNaN(t.getTime()) ? '—' : t.toLocaleString();
  };
  const localClock = (ts) => {
    if (!ts) return '—';
    const t = new Date(ts);
    return Number.isNaN(t.getTime()) ? '—' : t.toLocaleTimeString();
  };

  // ---- Indian number formatting (mirrors fx.js) -----------------------
  function groupIndian(intStr) {
    if (intStr.length <= 3) return intStr;
    const last3 = intStr.slice(-3);
    let rest = intStr.slice(0, -3);
    const parts = [];
    while (rest.length > 2) { parts.unshift(rest.slice(-2)); rest = rest.slice(0, -2); }
    if (rest.length) parts.unshift(rest);
    parts.push(last3);
    return parts.join(',');
  }
  function fmtInr(n, frac = 2, trim = false) {
    if (!Number.isFinite(n)) return '—';
    const neg = n < 0;
    let fixed = Math.abs(n).toFixed(frac);
    if (trim && Math.abs(n) > 0 && Math.abs(n) < 1) fixed = Math.abs(n).toFixed(8).replace(/0+$/, '');
    const dot = fixed.indexOf('.');
    const intStr = dot >= 0 ? fixed.slice(0, dot) : fixed;
    const dec = dot >= 0 ? fixed.slice(dot) : '';
    return '₹' + (neg ? '-' : '') + groupIndian(intStr) + dec;
  }
  const signInr = (n, frac = 2) => (Number.isFinite(n) ? (n >= 0 ? '+' : '') + fmtInr(n, frac) : '—');
  /** Big-money default: 2 decimals. */
  const inr = (n) => fmtInr(n, 2);
  /** Token-price default: adaptive decimals so tiny values stay readable. */
  const priceInr = (n) => {
    if (!Number.isFinite(n)) return '—';
    const abs = Math.abs(n);
    if (abs === 0) return '₹0.00';
    return fmtInr(n, abs >= 1 ? 2 : 4, true);
  };
  /** Card money value: ₹ when a rate is live, otherwise the SOL amount. */
  const bigMoney = (p, key) => {
    const iv = inrOf(p, key);
    if (iv != null) return inr(iv);
    const sv = p[key];
    return Number.isFinite(sv) ? fmt(sv, 5) + ' SOL' : '—';
  };
  /** Card signed money value (P&L): ₹ when live, otherwise signed SOL. */
  const bigSigned = (p, key) => {
    const iv = inrOf(p, key);
    if (iv != null) return signInr(iv);
    const sv = p[key];
    return Number.isFinite(sv) ? signed(sv, 5) + ' SOL' : '—';
  };
  /** Token price cell: ₹ when live, otherwise USD ($), else SOL. */
  const priceCell = (inrV, usd, sol) => {
    if (inrV != null) return priceInr(inrV);
    if (Number.isFinite(usd)) return '$' + fmt(usd, 10);
    if (Number.isFinite(sol)) return fmt(sol, 10) + ' SOL';
    return '—';
  };

  // ---- state -----------------------------------------------------------
  let state = {
    lastGoodAt: null,   // timestamp of the last SUCCESSFUL fetch
    conn: 'offline',    // offline | online | stale
    perf: null,
    heartbeat: null,
    positions: [],
    trades: [],
    equity: [],
    candidates: [],
    candidatesMeta: null,
    sources: [],
    lastErrors: [],
    fx: null,           // { available, usdInr, inrPerSol, solUsd, source, fetchedAt, cached, lastError }
    adaptive: null,     // adaptive intelligence view
    adaptivePerf: null, // { winRate, expectancyPct, maxDrawdownPct, lossStreak, winStreak, n }
    sideFilter: 'ALL'
  };

  const fxAvailable = () => state.fx && state.fx.available && Number(state.fx.usdInr) > 0;
  /** INR value for a *Sol field: prefer the API mirror, else compute, else SOL fallback. */
  function inrOf(p, solKey) {
    const mirror = p[solKey.replace(/Sol$/, 'Inr')];
    if (Number.isFinite(mirror)) return mirror;
    const fx = state.fx;
    if (fxAvailable() && Number(fx.inrPerSol) > 0 && Number.isFinite(p[solKey])) {
      return p[solKey] * fx.inrPerSol;
    }
    return null;
  }

  // ---- connection badge ------------------------------------------------
  function setConn(conn, extra) {
    state.conn = conn;
    const badge = $('conn');
    badge.className = 'conn ' + conn;
    if (conn === 'online') {
      badge.textContent = '🟢 Ubuntu API Connected';
    } else if (conn === 'stale') {
      badge.textContent = '🟡 Ubuntu API Offline — showing data from ' + extra;
    } else {
      badge.textContent = '🔴 Ubuntu API Offline';
    }
  }

  // ---- fetch with timeout ----------------------------------------------
  function fetchJson(url) {
    return new Promise((resolve, reject) => {
      const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      const timer = setTimeout(() => ctrl && ctrl.abort(), 8000);
      fetch(url, { signal: ctrl ? ctrl.signal : undefined })
        .then((r) => (r.ok ? r.json() : Promise.reject(new Error('HTTP ' + r.status))))
        .then((j) => { clearTimeout(timer); resolve(j); })
        .catch((e) => { clearTimeout(timer); reject(e); });
    });
  }

  async function poll() {
    try {
      const d = await fetchJson(API_BASE + '/api/dashboard');
      if (!d || !d.performance) throw new Error('bad dashboard payload');
      state.perf = d.performance;
      state.heartbeat = d.heartbeat;
      state.positions = d.portfolio && Array.isArray(d.portfolio.positions) ? d.portfolio.positions : [];
      state.trades = Array.isArray(d.trades) ? d.trades : [];
      state.equity = Array.isArray(d.equity) ? d.equity : [];
      state.candidates = Array.isArray(d.candidates) ? d.candidates : [];
      state.candidatesMeta = d.candidatesMeta || null;
      state.sources = Array.isArray(d.priceSources) ? d.priceSources : [];
      state.lastErrors = Array.isArray(d.lastErrors) ? d.lastErrors : [];
      state.fx = d.fx || null;
      state.adaptive = d.adaptive || null;
      state.adaptivePerf = d.adaptivePerf || null;
      state.lastGoodAt = Date.now();
      setConn('online');
      render();
    } catch (err) {
      if (state.lastGoodAt && state.perf) {
        setConn('stale', ago(state.lastGoodAt));
        const line = $('status-line');
        if (line) line.textContent = 'API unreachable (' + err.message + ') — data may be stale. Last update ' + ago(state.lastGoodAt) + '.';
      } else {
        setConn('offline');
        const line = $('status-line');
        if (line) line.textContent = 'API unreachable (' + err.message + ') — target ' + API_BASE;
        $('cards').innerHTML = '';
        $('positions-wrap').innerHTML = '';
        $('trades-wrap').innerHTML = '';
        $('perf-grid').innerHTML = '';
        $('live-grid').innerHTML = '';
        $('sys-grid').innerHTML = '';
        $('sources-wrap').innerHTML = '';
        $('candidates-wrap').innerHTML = '';
        $('errors-wrap').innerHTML = '';
        $('fx-line').textContent = '';
        showChartEmpty('Ubuntu API offline. Start dashboard-api.js on Ubuntu, then this dashboard will connect.');
      }
    }
  }

  // ---- renderers ---------------------------------------------------------
  function card(label, value, sub, title) {
    const c = el('div', 'card');
    c.appendChild(el('div', 'label', label));
    const v = el('div', 'value', value);
    if (title) v.title = title;
    c.appendChild(v);
    if (sub) c.appendChild(el('div', 'sub ' + upDown(sub.num), sub.text));
    return c;
  }

  function renderCards(p) {
    const cards = $('cards');
    cards.innerHTML = '';
    // Primary value in ₹ (real conversion); without a rate the card shows the
    // real SOL amount instead of an em-dash. SOL stays in the secondary line.
    const sol = (k) => (Number.isFinite(p[k]) ? p[k] : 0);
    cards.appendChild(card('EQUITY',
      bigMoney(p, 'equitySol'),
      { num: sol('totalPnlSol'), text: signed(sol('totalPnlSol'), 5) + ' SOL · ' + signedPct(p.pnlPct) },
      'Equity: ' + solMoney(sol('equitySol'))));
    cards.appendChild(card('TOTAL P&L',
      bigSigned(p, 'totalPnlSol'),
      { num: p.pnlPct, text: signedPct(p.pnlPct) },
      'Total P&L: ' + signed(sol('totalPnlSol'), 5) + ' SOL'));
    cards.appendChild(card('CASH',
      bigMoney(p, 'cashSol'),
      { num: 0, text: solMoney(sol('cashSol')) },
      'Cash: ' + solMoney(sol('cashSol'))));
    cards.appendChild(card('INVESTED',
      bigMoney(p, 'investedSol'),
      { num: 0, text: solMoney(sol('investedSol')) },
      'Invested: ' + solMoney(sol('investedSol'))));
    cards.appendChild(card('MARKET VALUE',
      bigMoney(p, 'marketValueSol'),
      { num: 0, text: solMoney(sol('marketValueSol')) },
      'Market value: ' + solMoney(sol('marketValueSol'))));
    cards.appendChild(card('UNREALIZED P&L',
      bigSigned(p, 'unrealizedPnlSol'),
      { num: sol('unrealizedPnlSol'), text: signed(sol('unrealizedPnlSol'), 5) + ' SOL' },
      'Unrealized P&L: ' + signed(sol('unrealizedPnlSol'), 5) + ' SOL'));
    cards.appendChild(card('REALIZED P&L',
      bigSigned(p, 'realizedPnlSol'),
      { num: sol('realizedPnlSol'), text: signed(sol('realizedPnlSol'), 5) + ' SOL' },
      'Realized P&L: ' + signed(sol('realizedPnlSol'), 5) + ' SOL'));
    cards.appendChild(card('STARTING CAPITAL',
      bigMoney(p, 'startingCapitalSol'),
      { num: 0, text: solMoney(sol('startingCapitalSol')) },
      'Starting capital: ' + solMoney(sol('startingCapitalSol'))));
  }

  function renderFxLine() {
    const line = $('fx-line');
    if (!line) return;
    if (!fxAvailable()) {
      line.textContent = 'Exchange rate unavailable — showing SOL/USD values.' +
        (state.fx && state.fx.lastError ? ' (' + state.fx.lastError + ')' : '');
      line.classList.add('warn');
      return;
    }
    line.classList.remove('warn');
    const fx = state.fx;
    let text = '1 USD = ₹' + fmt(fx.usdInr, 2);
    if (Number(fx.inrPerSol) > 0) text += '  ·  1 SOL ≈ ' + fmtInr(fx.inrPerSol);
    text += fx.cached
      ? '  ·  RATE CACHED (live refresh failing) · as of ' + localClock(fx.fetchedAt)
      : '  ·  live · updated ' + localClock(fx.fetchedAt);
    line.textContent = text;
    if (fx.source) line.title = 'Exchange rate source: ' + fx.source;
  }

  function renderLive(hb, p) {
    const g = $('live-grid');
    g.innerHTML = '';
    const cell = (k, v, cls) => {
      const d = el('div', 'live-cell');
      d.appendChild(el('div', 'k', k));
      d.appendChild(el('div', 'v' + (cls ? ' ' + cls : ''), v));
      g.appendChild(d);
    };
    cell('Agent state', hb && hb.state ? hb.state : 'unknown', hb && hb.state === 'running' ? 'good' : '');
    cell('Paper mode', 'true (paper only)', 'good');
    cell('Custody', hb && hb.custody ? hb.custody : 'local');
    cell('Scans', hb ? String(hb.scans) : '—');
    cell('Uptime', hb && Number.isFinite(hb.uptimeSec) ? hb.uptimeSec + 's' : '—');
    cell('Last scan', hb && hb.lastScanAt ? ago(hb.lastScanAt) : '—');
    cell('Last portfolio write', p && p.updatedAt ? ago(p.updatedAt) : '—');
    cell('Open positions', String(state.positions.length));
  }

  function renderPositions() {
    const wrap = $('positions-wrap');
    wrap.innerHTML = '';
    if (!state.positions.length) {
      wrap.appendChild(el('div', 'empty', 'No open positions.'));
      return;
    }
    const tbl = el('table');
    const thead = el('thead');
    const hr = el('tr');
    ['SYMBOL', 'QTY', 'ENTRY (₹)', 'CURRENT (₹)', 'COST (₹)', 'MKT VALUE (₹)', 'UNREALIZED P&L (₹)', 'P&L %', 'OPENED'].forEach((h) => {
      hr.appendChild(el('th', h === 'SYMBOL' || h === 'OPENED' ? '' : 'num', h));
    });
    thead.appendChild(hr);
    tbl.appendChild(thead);

    const tb = el('tbody');
    for (const pos of state.positions) {
      const tr = el('tr');
      const pnlInr = pos.unrealizedPnlInr != null ? pos.unrealizedPnlInr
        : (Number.isFinite(pos.unrealizedPnlSol) && Number.isFinite(state.fx && state.fx.inrPerSol)
          ? pos.unrealizedPnlSol * state.fx.inrPerSol : null);
      const pnlSol = pos.unrealizedPnlSol || 0;
      const pct = pos.unrealizedPnlPct || 0;
      const cls = pnlSol > 0 ? 'up' : pnlSol < 0 ? 'down' : 'muted';
      const pill = pnlSol > 0 ? 'profit' : pnlSol < 0 ? 'loss' : 'flat';
      const costInr = pos.costInr != null ? pos.costInr
        : (Number.isFinite(pos.costSol) && Number.isFinite(state.fx && state.fx.inrPerSol) ? pos.costSol * state.fx.inrPerSol : null);
      const mvInr = pos.marketValueInr != null ? pos.marketValueInr
        : (Number.isFinite(pos.marketValueSol) && Number.isFinite(state.fx && state.fx.inrPerSol) ? pos.marketValueSol * state.fx.inrPerSol : null);
      const entryInr = pos.entryPriceInr != null ? pos.entryPriceInr
        : (Number.isFinite(pos.entryPriceUsd) && fxAvailable() ? pos.entryPriceUsd * state.fx.usdInr : null);
      const curInr = pos.currentPriceInr != null ? pos.currentPriceInr
        : (Number.isFinite(pos.currentPriceUsd) && fxAvailable() ? pos.currentPriceUsd * state.fx.usdInr : null);
      const symTxt = pos.symbol + (pos.mint ? ' · ' + String(pos.mint).slice(0, 4) + '…' : '');
      const rowCells = [
        symTxt,
        fmt(pos.quantity, 4),
        priceCell(entryInr, pos.entryPriceUsd, pos.entryPriceSol != null ? pos.entryPriceSol : pos.entryPrice),
        priceCell(curInr, pos.currentPriceUsd, pos.currentPriceSol != null ? pos.currentPriceSol : pos.currentPrice),
        costInr != null ? inr(costInr) : (Number.isFinite(pos.costSol) ? fmt(pos.costSol, 6) + ' SOL' : '—'),
        mvInr != null ? inr(mvInr) : (Number.isFinite(pos.marketValueSol) ? fmt(pos.marketValueSol, 6) + ' SOL' : '—'),
        pnlInr != null ? signInr(pnlInr) : (Number.isFinite(pnlSol) ? signed(pnlSol, 6) + ' SOL' : '—'),
        signedPct(pct), localTime(pos.openedAt)
      ];
      rowCells.forEach((txt, i) => {
        const td = el('td', '', txt);
        if (i === 0) td.className = 'pos';
        if (i >= 1 && i <= 5) td.className = 'num';
        if (i === 6) { td.className = 'num ' + cls; }
        if (i === 7) { td.className = 'num'; td.innerHTML = ''; const sp = el('span', 'pill ' + pill, signedPct(pct)); td.appendChild(sp); }
        if (i === 8) td.className = 'muted';
        tr.appendChild(td);
      });
      // SOL details in the tooltip — never the main display.
      tr.title = [
        'Entry: ' + fmt(pos.entryPriceSol != null ? pos.entryPriceSol : pos.entryPrice, 12) + ' SOL' +
          (Number.isFinite(pos.entryPriceUsd) ? ' ($' + fmt(pos.entryPriceUsd, 10) + ')' : ''),
        'Current: ' + fmt(pos.currentPriceSol != null ? pos.currentPriceSol : pos.currentPrice, 12) + ' SOL' +
          (Number.isFinite(pos.currentPriceUsd) ? ' ($' + fmt(pos.currentPriceUsd, 10) + ')' : ''),
        'Cost: ' + fmt(pos.costSol, 6) + ' SOL · Mkt: ' + fmt(pos.marketValueSol, 6) + ' SOL',
        'Unrealized: ' + signed(pnlSol, 6) + ' SOL'
      ].join('\n');
      tb.appendChild(tr);
    }
    tbl.appendChild(tb);
    wrap.appendChild(tbl);
  }

  function renderTrades() {
    const wrap = $('trades-wrap');
    wrap.innerHTML = '';
    const list = state.trades.filter((t) => state.sideFilter === 'ALL' || t.side === state.sideFilter);
    if (!list.length) {
      wrap.appendChild(el('div', 'empty', 'No trades yet.'));
      return;
    }
    const tbl = el('table');
    const thead = el('thead');
    const hr = el('tr');
    ['TIME', 'SIDE', 'SYMBOL', 'QTY', 'PRICE (₹)', 'VALUE (₹)', 'P&L (₹)', 'P&L %'].forEach((h) => {
      hr.appendChild(el('th', h === 'SIDE' || h === 'SYMBOL' || h === 'TIME' ? '' : 'num', h));
    });
    thead.appendChild(hr);
    tbl.appendChild(thead);

    const tb = el('tbody');
    for (const t of list) {
      const tr = el('tr');
      const sell = t.side === 'SELL';
      const pnlSol = t.realizedPnlSol || 0;
      const pct = t.realizedPnlPct || 0;
      const cls = pnlSol > 0 ? 'up' : pnlSol < 0 ? 'down' : 'muted';
      const pill = pnlSol > 0 ? 'profit' : pnlSol < 0 ? 'loss' : 'flat';
      const priceInrV = t.priceInr != null ? t.priceInr
        : (Number.isFinite(t.priceUsd) && fxAvailable() ? t.priceUsd * state.fx.usdInr : null);
      const valueInrV = t.valueInr != null ? t.valueInr
        : (Number.isFinite(t.valueSol) && Number.isFinite(state.fx && state.fx.inrPerSol) ? t.valueSol * state.fx.inrPerSol : null);
      const pnlInrV = t.realizedPnlInr != null ? t.realizedPnlInr
        : (Number.isFinite(t.realizedPnlSol) && Number.isFinite(state.fx && state.fx.inrPerSol) ? t.realizedPnlSol * state.fx.inrPerSol : null);
      const vals = [
        localTime(t.timestamp), t.side, t.symbol, fmt(t.quantity, 4),
        priceCell(priceInrV, t.priceUsd, t.price),
        valueInrV != null ? inr(valueInrV) : (Number.isFinite(t.valueSol) ? fmt(t.valueSol, 6) + ' SOL' : '—'),
        sell ? (pnlInrV != null ? signInr(pnlInrV) : (Number.isFinite(pnlSol) ? signed(pnlSol, 6) + ' SOL' : '—')) : '—',
        sell ? signedPct(pct) : '—'
      ];
      vals.forEach((txt, i) => {
        const td = el('td', '', txt);
        if (i === 0) td.className = 'muted';
        if (i === 1) { td.textContent = ''; const s = el('span', 'side ' + t.side, t.side); td.appendChild(s); }
        if (i === 2) td.className = 'pos';
        if (i >= 3) td.className = 'num';
        if (i === 6 && sell) td.className = 'num ' + cls;
        if (i === 7 && sell) { td.className = 'num'; td.textContent = ''; td.appendChild(el('span', 'pill ' + pill, signedPct(pct))); }
        tr.appendChild(td);
      });
      const tooltip = [
        'Price: ' + fmt(t.price, 10) + ' SOL' + (Number.isFinite(t.priceUsd) ? ' ($' + fmt(t.priceUsd, 10) + ')' : ''),
        'Value: ' + fmt(t.valueSol, 6) + ' SOL'
      ];
      if (sell) tooltip.push('P&L: ' + signed(pnlSol, 6) + ' SOL');
      tr.title = tooltip.join('\n');
      tb.appendChild(tr);
    }
    tbl.appendChild(tb);
    wrap.appendChild(tbl);
  }

  function renderSystem(hb) {
    const g = $('sys-grid');
    g.innerHTML = '';
    const cell = (k, v, cls) => {
      const d = el('div', 'sys-cell');
      d.appendChild(el('div', 'k', k));
      d.appendChild(el('div', 'v' + (cls ? ' ' + cls : ''), v));
      g.appendChild(d);
    };
    cell('Market', hb && hb.market ? hb.market : 'REAL SOLANA');
    cell('Execution', hb && hb.execution ? hb.execution : 'PAPER ONLY', 'good');
    cell('Wallet', hb && hb.wallet ? hb.wallet : 'DISABLED', 'good');
    cell('Signer', hb && hb.signer ? hb.signer : 'DISABLED', 'good');
    cell('Broadcast', hb && hb.broadcast ? hb.broadcast : 'DISABLED', 'good');
    cell('SOL price', state.solPriceUsd ? '$' + fmt(state.solPriceUsd, 2) : '—');
    cell('Exchange rate', fxAvailable()
      ? '1 USD = ₹' + fmt(state.fx.usdInr, 2) + (state.fx.cached ? ' (cached)' : '')
      : 'unavailable', fxAvailable() && !state.fx.cached ? '' : 'warn');
    cell('Positions', (state.positions.length) + ' / ' + (hb && hb.maxPositions ? hb.maxPositions : 3));
    cell('Candidates', state.candidatesMeta ? String(state.candidatesMeta.count || 0) : '—');
    cell('Agent lock', hb && hb.state ? hb.state : '—', hb && hb.state === 'running' ? 'good' : '');
  }

  function renderSources() {
    const wrap = $('sources-wrap');
    wrap.innerHTML = '';
    if (!state.sources.length) {
      wrap.appendChild(el('div', 'empty', 'No price sources reported yet.'));
      return;
    }
    for (const s of state.sources) {
      const row = el('div', 'source-row');
      const left = el('span');
      const dot = el('span', 'source-dot ' + (s.status || 'unknown'));
      dot.textContent = '';
      left.appendChild(dot);
      left.appendChild(document.createTextNode(s.name || '?'));
      if (s.role) left.appendChild(el('span', 'source-role', s.role));
      row.appendChild(left);
      const right = el('span');
      if (s.status === 'error') {
        right.className = 'source-err';
        right.textContent = 'error' + (s.lastError ? ' — ' + s.lastError : '');
      } else if (s.lastOkAt) {
        right.textContent = 'ok · ' + ago(s.lastOkAt);
      } else {
        right.textContent = 'not queried yet';
      }
      row.appendChild(right);
      wrap.appendChild(row);
    }
    // Exchange-rate source, when known.
    if (fxAvailable() && state.fx.source) {
      const row = el('div', 'source-row');
      const left = el('span');
      const dot = el('span', 'source-dot ' + (state.fx.cached ? 'unknown' : 'ok'));
      left.appendChild(dot);
      left.appendChild(document.createTextNode(state.fx.source + ' (USD/INR)'));
      row.appendChild(left);
      const right = el('span', 'source-err', state.fx.cached ? 'cached — live refresh failing' : 'ok · ' + localClock(state.fx.fetchedAt));
      row.appendChild(right);
      wrap.appendChild(row);
    }
  }

  function renderCandidates() {
    const wrap = $('candidates-wrap');
    wrap.innerHTML = '';
    const meta = state.candidatesMeta;
    $('cand-meta').textContent = meta && meta.scannedAt
      ? 'scanned ' + ago(meta.scannedAt) + ' · ' + meta.count + ' candidate(s) · ' + meta.openPositions + '/' + meta.maxPositions + ' open'
      : '';
    if (!state.candidates.length) {
      wrap.appendChild(el('div', 'empty', 'No candidates yet — the agent writes its discovery scan to candidates.json as it runs.'));
      return;
    }
    const tbl = el('table');
    const thead = el('thead');
    const hr = el('tr');
    ['SYMBOL', 'SCORE', '1H', '5M', 'PRICE (₹)', 'PRICE SOL', 'LIQ', 'VOL', 'DECISION'].forEach((h) => {
      hr.appendChild(el('th', h === 'SYMBOL' || h === 'DECISION' ? '' : 'num', h));
    });
    thead.appendChild(hr);
    tbl.appendChild(thead);
    const tb = el('tbody');
    for (const c of state.candidates) {
      const tr = el('tr');
      const rec5 = c.recoveryStatus === 'warming'
        ? 'warming(' + (c.recoverySamples || 0) + ')'
        : signedPct(c.recoveryPct);
      const decision = c.decision === 'BUY' ? 'BUY' : (c.reason ? 'FILTER · ' + c.reason : '—');
      const priceInrV = c.priceInr != null ? c.priceInr
        : (Number.isFinite(c.priceUsd) && fxAvailable() ? c.priceUsd * state.fx.usdInr : null);
      const vals = [
        c.symbol, String(c.score), signedPct(c.change1hPct), rec5,
        priceCell(priceInrV, c.priceUsd, c.priceSol), fmt(c.priceSol, 12), fmtCompact(c.liquidityUsd), fmtCompact(c.volume24hUsd), decision
      ];
      vals.forEach((txt, i) => {
        const td = el('td', '', txt);
        if (i === 0) td.className = 'pos';
        if (i >= 1 && i <= 7) td.className = 'num';
        if (i === 8) {
          td.className = '';
          td.textContent = '';
          td.appendChild(el('span', 'decision-pill ' + (c.decision === 'BUY' ? 'buy' : 'filter'), decision));
        }
        tr.appendChild(td);
      });
      tr.title = 'USD price: $' + (Number.isFinite(c.priceUsd) ? fmt(c.priceUsd, 10) : '—') +
        ' · Liq: $' + fmtCompact(c.liquidityUsd) + ' · Vol: $' + fmtCompact(c.volume24hUsd);
      tb.appendChild(tr);
    }
    tbl.appendChild(tb);
    wrap.appendChild(tbl);
  }

  function renderErrors() {
    const wrap = $('errors-wrap');
    wrap.innerHTML = '';
    if (!state.lastErrors.length) {
      wrap.appendChild(el('div', 'empty', 'No errors recorded.'));
      return;
    }
    for (const e of state.lastErrors) {
      const row = el('div', 'error-row');
      row.appendChild(el('span', 'error-tag', '[' + e.tag + ']'));
      row.appendChild(el('span', 'error-msg', e.msg));
      row.appendChild(el('span', 'error-time', ago(e.ts)));
      wrap.appendChild(row);
    }
  }

  const fmtCompact = (n) => {
    if (!Number.isFinite(n)) return '—';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return String(Math.round(n));
  };

  function renderPerf(p) {
    const g = $('perf-grid');
    g.innerHTML = '';
    const cell = (k, v, cls) => {
      const d = el('div', 'perf-cell');
      d.appendChild(el('div', 'k', k));
      d.appendChild(el('div', 'v' + (cls ? ' ' + cls : ''), v));
      g.appendChild(d);
    };
    const inrOrSol = (vInr, vSol, sign = true) => {
      if (Number.isFinite(vInr)) return sign ? signInr(vInr) : inr(vInr);
      return Number.isFinite(vSol) ? (sign ? signed(vSol, 6) : fmt(vSol, 6)) + ' SOL' : '—';
    };
    cell('Total trades', String(p.totalTrades || 0));
    cell('Winning trades', String(p.winningTrades || 0), 'up');
    cell('Losing trades', String(p.losingTrades || 0), 'down');
    cell('Win rate', fmt(p.winRate, 2) + '%');
    cell('Avg win', inrOrSol(p.avgWinInr, p.avgWinSol), p.avgWinSol > 0 ? 'up' : '');
    cell('Avg loss', inrOrSol(p.avgLossInr, p.avgLossSol), p.avgLossSol < 0 ? 'down' : '');
    cell('Best trade', inrOrSol(p.bestTradeInr, p.bestTradeSol), 'up');
    cell('Worst trade', inrOrSol(p.worstTradeInr, p.worstTradeSol), 'down');
  }

  // ---- adaptive intelligence --------------------------------------------
  function renderAdaptive() {
    const g = $('adaptive-grid');
    const sub = $('adaptive-sub');
    if (!g) return;
    g.innerHTML = '';
    if (sub) sub.innerHTML = '';
    const a = state.adaptive;
    if (!a || !a.enabled) {
      g.appendChild(el('div', 'empty', 'Adaptive layer disabled or not reported yet. Start agentd.js with the adaptive layer enabled to see agent-loop / reflection / regime / learned gates here.'));
      return;
    }
    const p = a.policy || {};
    const r = a.regime || {};
    const mh = a.marketHealth;
    const perf = state.adaptivePerf || (a.performance && (a.performance.week || a.performance.allTime)) || null;

    const cell = (k, v, cls) => {
      const d = el('div', 'adaptive-cell');
      d.appendChild(el('div', 'k', k));
      d.appendChild(el('div', 'v' + (cls ? ' ' + cls : ''), v));
      g.appendChild(d);
    };
    const modeCls = p.mode === 'watchOnly' ? 'warn' : p.mode === 'selective' ? '' : 'good';
    const regimeCls = r.regime === 'dump' || r.regime === 'recovery' ? 'warn' : r.regime === 'bull' ? 'good' : '';

    cell('Strategy version', p.strategyVersion || 'V1');
    cell('Mode', (p.mode || 'active') + (p.source === 'llm' ? ' (LLM)' : ''), modeCls);
    cell('Regime', (r.regime || 'UNKNOWN') + (r.confidence ? ' · ' + Math.round(r.confidence * 100) + '%' : ''), regimeCls);
    cell('Min score', String(p.minScore != null ? p.minScore : 60));
    cell('Max buys (session)', String(p.maxBuys != null ? p.maxBuys : '—') + ' (' + (p.buysThisSession || 0) + ' used)');
    cell('Size multiplier', p.sizeMultiplier != null ? p.sizeMultiplier + '×' : '1.0×');
    cell('Market health', mh ? mh.score + '/100 · ' + mh.status + (mh.gate ? ' (GATED)' : '') : '—', mh && mh.gate ? 'warn' : '');
    if (perf) {
      cell('Win rate', fmt(perf.winRate, 2) + '% (n=' + perf.n + ')');
      cell('Expectancy', signedPct(perf.expectancyPct));
      cell('Max drawdown', '-' + fmt(Math.abs(perf.maxDrawdownPct || 0), 2) + '%');
      cell('Streaks', 'L' + (perf.lossStreak || 0) + ' / W' + (perf.winStreak || 0), (perf.lossStreak || 0) >= 3 ? 'warn' : '');
    }
    const s = a.schedule;
    if (s) {
      cell('Last agent-loop', s.lastAgentLoopAt ? ago(s.lastAgentLoopAt) : 'never');
      cell('Next agent-loop', s.nextAgentLoopAt ? localClock(s.nextAgentLoopAt) : '—');
      cell('Last reflection', s.lastReflectionAt ? ago(s.lastReflectionAt) : 'never');
      cell('Next reflection', s.nextReflectionAt ? localClock(s.nextReflectionAt) : '—');
    }

    if (!sub) return;
    // Learned gates + experiments + approvals + lessons + changes.
    const block = (title, rows) => {
      if (!rows || !rows.length) return '';
      const b = el('div', 'adaptive-block');
      b.appendChild(el('div', 'adaptive-block-title', title));
      for (const row of rows) b.appendChild(row);
      return b;
    };
    const gateRows = (a.gates && a.gates.list || []).map((c) => {
      const n = el('div', 'adaptive-row');
      n.appendChild(el('span', 'muted', c.clusterKey + ': '));
      n.appendChild(document.createTextNode(c.gates.map((x) => x.parameter + '=' + x.value + ' (c' + Math.round(x.confidence * 100) + '%, n' + x.sample + ')').join(', ')));
      return n;
    });
    const expRows = ((a.experiments && a.experiments.experiments && a.experiments.experiments.recent) || []).slice(-6).map((e) => {
      const n = el('div', 'adaptive-row');
      const pill = el('span', 'pill ' + (e.state === 'PROMOTED' ? 'profit' : e.state === 'REJECTED' || e.state === 'ROLLED_BACK' ? 'loss' : 'flat'), e.state);
      n.appendChild(pill);
      n.appendChild(document.createTextNode(' ' + e.type + ': ' + e.parameter + ' ' + e.oldValue + '→' + e.newValue));
      return n;
    });
    const apprRows = ((a.experiments && a.experiments.approvals && a.experiments.approvals.pendingList) || []).slice(-4).map((x) => {
      const n = el('div', 'adaptive-row warn');
      n.appendChild(el('span', 'k', 'PENDING ' + (x.priority || '') + ' · '));
      n.appendChild(document.createTextNode(x.title));
      return n;
    });
    const changeRows = (a.policyChanges || []).slice(-6).map((c) => {
      const n = el('div', 'adaptive-row');
      const g = c.grade ? el('span', 'pill ' + (String(c.grade).includes('POSITIVE') ? 'profit' : String(c.grade).includes('NEGATIVE') ? 'loss' : 'flat'), String(c.grade)) : el('span', 'pill flat', 'PENDING');
      n.appendChild(g);
      n.appendChild(document.createTextNode(' ' + c.strategyVersion + ' ' + c.parameter + ' ' + c.oldValue + '→' + c.newValue));
      return n;
    });
    const lessonRows = (a.lessons || []).slice(-6).map((l) => {
      const n = el('div', 'adaptive-row');
      n.appendChild(el('span', 'muted', '[' + (l.type || 'lesson') + '] '));
      n.appendChild(document.createTextNode(l.summary || l.key || ''));
      return n;
    });
    const rbCount = a.experiments && a.experiments.rollback ? a.experiments.rollback.rolledBackExperiments : 0;
    const rollbackRow = el('div', 'adaptive-row');
    rollbackRow.appendChild(el('span', 'k', 'Rollbacks: '));
    rollbackRow.appendChild(document.createTextNode(String(rbCount) + ' · current baseline ' + ((a.baseline && a.baseline.versionId) || 'V1') + ' (minScore ' + ((a.baseline && a.baseline.minScoreBase) || 60) + ')'));
    const blocks = [
      block('LEARNED GATES (' + ((a.gates && a.gates.clusters) || 0) + ' clusters)', gateRows),
      block('EXPERIMENTS', expRows),
      block('PENDING APPROVALS', apprRows),
      block('POLICY CHANGES', changeRows),
      block('LESSONS', lessonRows)
    ];
    const wrap = el('div', 'adaptive-blocks');
    for (const b of blocks) if (b) wrap.appendChild(b);
    const reason = el('div', 'adaptive-reason');
    reason.appendChild(el('span', 'k', 'Policy reason: '));
    reason.appendChild(document.createTextNode(p.reason || '—'));
    sub.appendChild(wrap);
    sub.appendChild(reason);
    if (rollbackRow) sub.appendChild(rollbackRow);
  }

  // ---- equity curve (observed data only) --------------------------------
  function showChartEmpty(msg) {
    $('chart-empty').textContent = msg;
    $('chart-empty').classList.remove('hidden');
  }
  function hideChartEmpty() { $('chart-empty').classList.add('hidden'); }

  function drawEquity() {
    const canvas = $('equity-chart');
    const empty = $('chart-empty');
    if (!state.equity.length) {
      empty.classList.remove('hidden');
      empty.textContent = 'No equity history recorded yet. The agent appends a point after each scan — check back after it runs for a minute or two.';
      return;
    }
    hideChartEmpty();

    // Point chart at its rendered size (retina-aware).
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.max(2, Math.floor(rect.width * dpr));
    canvas.height = Math.max(2, Math.floor(rect.height * dpr));
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    const W = rect.width, H = rect.height;

    // Equity points in INR (observed equity × real conversion); falls back
    // to SOL when no rate is available.
    const hasRate = fxAvailable() && Number(state.fx.inrPerSol) > 0;
    const pts = state.equity.map((r) => {
      const inrV = Number.isFinite(r.equityInr) ? r.equityInr
        : (hasRate && Number.isFinite(r.equitySol) ? r.equitySol * state.fx.inrPerSol : null);
      return { ts: r.ts, eq: inrV != null ? inrV : r.equitySol };
    }).filter((p) => Number.isFinite(p.eq) && p.eq !== null && p.eq !== undefined);
    if (!pts.length) { showChartEmpty('No usable equity history yet.'); return; }
    const minT = Math.min.apply(null, pts.map((p) => p.ts));
    const maxT = Math.max.apply(null, pts.map((p) => p.ts));
    const eqs = pts.map((p) => p.eq);
    const minEq = Math.min.apply(null, eqs);
    const maxEq = Math.max.apply(null, eqs);
    const spanEq = maxEq - minEq || 1;

    const padL = 10, padR = 10, padT = 12, padB = 24;
    const x = (ts) => padL + (maxT === minT ? 0.5 : (ts - minT) / (maxT - minT)) * (W - padL - padR);
    const y = (eq) => padT + (1 - (eq - minEq) / spanEq) * (H - padT - padB);

    // grid + zero-ish baseline
    ctx.clearRect(0, 0, W, H);
    ctx.strokeStyle = '#1e2634';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i <= 4; i++) {
      const yy = padT + (i / 4) * (H - padT - padB);
      ctx.moveTo(padL, yy);
      ctx.lineTo(W - padR, yy);
    }
    ctx.stroke();

    // area + line
    ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(x(p.ts), y(p.eq)) : ctx.moveTo(x(p.ts), y(p.eq))));
    ctx.strokeStyle = '#4f8cff';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.lineTo(x(pts[pts.length - 1].ts), H - padB);
    ctx.lineTo(x(pts[0].ts), H - padB);
    ctx.closePath();
    ctx.fillStyle = 'rgba(79, 140, 255, 0.10)';
    ctx.fill();

    // first/last labels
    ctx.fillStyle = '#8a94a6';
    ctx.font = '11px monospace';
    ctx.textBaseline = 'alphabetic';
    const last = pts[pts.length - 1];
    ctx.fillStyle = last.eq >= minEq + spanEq * 0.5 ? '#e6ebf2' : '#8a94a6';
    ctx.fillText(hasRate ? fmtInr(last.eq) : fmt(last.eq, 5) + ' SOL', padL, H - 6);
    ctx.fillStyle = '#8a94a6';
    ctx.fillText(new Date(pts[0].ts).toLocaleDateString(), padL, H - 6);
    ctx.textAlign = 'right';
    ctx.fillText(new Date(last.ts).toLocaleString(), W - padR, H - 6);
    ctx.textAlign = 'left';
    canvas.title = hasRate
      ? 'Equity plotted in ₹ (SOL × real SOL/USD × USD/INR). ' + fmt(last.eq, 4) + ' currently.'
      : 'No INR rate available — equity plotted in SOL.';
  }

  // ---- main render --------------------------------------------------------
  function render() {
    const p = state.perf;
    if (!p) return;
    state.solPriceUsd = state.heartbeat ? state.heartbeat.solPriceUsd : null;
    renderFxLine();
    renderCards(p);
    renderLive(state.heartbeat, p);
    renderSystem(state.heartbeat);
    renderSources();
    renderCandidates();
    renderErrors();
    renderPositions();
    renderTrades();
    renderPerf(p);
    renderAdaptive();
    drawEquity();
    const line = $('status-line');
    if (line && state.conn !== 'stale') {
      line.textContent = 'refreshed ' + ago(state.lastGoodAt) + ' · api ' + API_BASE +
        (state.heartbeat && state.heartbeat.lastScanAt ? ' · last scan ' + ago(state.heartbeat.lastScanAt) : '');
    }
  }

  // ---- wiring -------------------------------------------------------------
  document.addEventListener('DOMContentLoaded', () => {
    $('status-line').textContent = 'connecting to ' + API_BASE + ' …';

    const filter = $('side-filter');
    if (filter) {
      filter.addEventListener('click', (e) => {
        const b = e.target.closest('button');
        if (!b) return;
        state.sideFilter = b.dataset.side;
        filter.querySelectorAll('button').forEach((x) => x.classList.toggle('active', x === b));
        renderTrades();
      });
    }

    window.addEventListener('resize', () => { if (state.perf) drawEquity(); });

    poll();
    setInterval(poll, POLL_MS);
  });
})();
