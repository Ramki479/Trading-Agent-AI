#!/usr/bin/env node
/**
 * market-data.js — REAL Solana market-data layer for the paper trader.
 *
 * Dependency-free (uses Node's global fetch). 100% read-only: this module only
 * ever fetches public market data; it cannot trade, sign, or broadcast.
 *
 * Sources
 * -------
 *   dex      — DexScreener public API (https://api.dexscreener.com).
 *              This is the DEFAULT real source (no key required).
 *              Discovery feeds: newest token profiles, latest + top boosts.
 *   gt       — GeckoTerminal public API (https://www.geckoterminal.com/dex-api).
 *              DISCOVERY FEED ONLY (trending + new Solana pools). GeckoTerminal
 *              mints are resolved through the DexScreener pair batch endpoint,
 *              so every candidate shares one real price schema — GeckoTerminal
 *              widens the universe, it never becomes a second price provider.
 *   circuit  — optional PRIMARY when CIRCUIT_PRICE_API_URL is set
 *              (expected JSON shape documented below). Falls back to dex.
 *   mock     — TEST-ONLY provider activated by CIRCUIT_MOCK_MARKET_FILE.
 *              It replays a local JSON fixture. Never used in production.
 *
 * Every price carries provenance metadata:
 *   { priceUsd, priceSol, source, timestamp, ageMs }
 *
 * priceSol is ALWAYS derived from the real SOL price
 * (priceUsd / solPriceUsd) — never from an approximation.
 *
 * Safety: no wallet, no keys, no signing, no broadcast. Read-only market data.
 */

'use strict';

const fs = require('fs');
const path = require('path');

const WRAPPED_SOL_MINT = 'So11111111111111111111111111111111111111112';
const DEFAULT_TIMEOUT_MS = 8000;
const MAX_TOKENS_PER_REQUEST = 30;   // DexScreener batch limit
const DEFAULT_SOL_PRICE_CACHE_MS = 30000;

/* ------------------------------------------------------------------ *
 * Address validation (Solana base58 mint addresses).
 * ------------------------------------------------------------------ */

const ADDR_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

function isValidSolanaAddress(addr) {
  return typeof addr === 'string' && ADDR_RE.test(addr);
}

/* ------------------------------------------------------------------ *
 * HTTP helper with timeout + error classification.
 * ------------------------------------------------------------------ */

async function fetchJson(url, { timeoutMs = DEFAULT_TIMEOUT_MS, label = 'http' } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(url, { signal: ctrl.signal, headers: { accept: 'application/json' } });
  } catch (err) {
    const isAbort = err && (err.name === 'AbortError' || err.code === 'ABORT_ERR');
    throw new Error(isAbort ? `${label}: timeout after ${timeoutMs}ms` : `${label}: ${err.message}`);
  } finally {
    clearTimeout(timer);
  }
  if (!res.ok) {
    throw new Error(`${label}: HTTP ${res.status} for ${url.slice(0, 120)}`);
  }
  return res.json();
}

/* ------------------------------------------------------------------ *
 * Price helpers.
 * ------------------------------------------------------------------ */

function isValidPrice(p) {
  return p && typeof p.priceUsd === 'number' && Number.isFinite(p.priceUsd) && p.priceUsd > 0 &&
    typeof p.priceSol === 'number' && Number.isFinite(p.priceSol) && p.priceSol > 0 &&
    Number.isFinite(p.timestamp);
}

/** Age in ms of a price at the current moment. */
function priceAgeMs(p, now = Date.now()) {
  return Math.max(0, now - p.timestamp);
}

/**
 * Compare two prices (same asset, different providers). Returns
 * { ok, divergencePct } — ok=false when relative divergence is abnormal.
 */
function comparePrices(a, b, maxDivergencePct) {
  if (!isValidPrice(a) || !isValidPrice(b)) return { ok: false, divergencePct: null };
  const hi = Math.max(a.priceUsd, b.priceUsd);
  const lo = Math.min(a.priceUsd, b.priceUsd);
  if (hi <= 0) return { ok: false, divergencePct: null };
  const divergencePct = ((hi - lo) / hi) * 100;
  return { ok: divergencePct <= maxDivergencePct, divergencePct: Math.round(divergencePct * 100) / 100 };
}

/* ------------------------------------------------------------------ *
 * Mock provider (tests only). Activated by CIRCUIT_MOCK_MARKET_FILE.
 *
 * Fixture shape:
 *   {
 *     "solPriceUsd": 150,
 *     "tokens": [
 *       {
 *         "symbol": "DIPRISE",
 *         "mint": "<valid base58 mint>",
 *         "priceUsd": 0.00001, "priceSol": 6.67e-8,
 *         "liquidityUsd": 150000, "volume24hUsd": 500000,
 *         "change1hPct": -20, "change5mPct": 2.5,
 *         "series": [6.67e-8, 6.67e-8, ...],   // optional priceSol walk
 *         "fail": false,      // simulate per-token price failure
 *         "stale": false,     // rejected at discovery (never a candidate)
 *         "invalid": false,   // rejected at discovery (never a candidate)
 *         "staleAtBuy": false,// candidate, but price is stale at decision time
 *         "invalidAtBuy": false // candidate, but price invalid at decision time
 *       }
 *     ],
 *     "failAll": false  // simulate total provider outage
 *   }
 * ------------------------------------------------------------------ */

function loadMockFixture(file) {
  const raw = fs.readFileSync(file, 'utf8');
  const fx = JSON.parse(raw);
  if (!fx || !Array.isArray(fx.tokens)) throw new Error('mock fixture must have a tokens array');
  const byMint = new Map();
  for (const t of fx.tokens) byMint.set(t.mint, Object.assign({}, t));
  return { solPriceUsd: Number(fx.solPriceUsd) || 150, byMint, failAll: !!fx.failAll };
}

function createMockProvider(mockFile, { maxPriceAgeMs }) {
  const fx = loadMockFixture(mockFile);
  const seriesIdx = new Map();

  const advance = (mint) => {
    const t = fx.byMint.get(mint);
    if (!t || !Array.isArray(t.series) || !t.series.length) return null;
    const i = seriesIdx.get(mint) || 0;
    seriesIdx.set(mint, i + 1);
    return t.series[Math.min(i, t.series.length - 1)];
  };

  return {
    name: 'mock',
    label: 'mock',
    async getSolPriceUsd() {
      if (fx.failAll) throw new Error('mock provider unavailable');
      return { priceUsd: fx.solPriceUsd, priceSol: 1, source: 'mock', timestamp: Date.now(), ageMs: 0 };
    },
    async discoverCandidates() {
      if (fx.failAll) throw new Error('mock provider unavailable');
      const out = [];
      for (const t of fx.byMint.values()) {
        if (t.stale || t.invalid) continue; // discovery rejects bad entries
        out.push({
          symbol: t.symbol,
          mint: t.mint,
          priceUsd: Number(t.priceUsd) || 0,
          priceSol: Number(t.priceSol) || 0,
          liquidityUsd: Number(t.liquidityUsd) || 0,
          volume24hUsd: Number(t.volume24hUsd) || 0,
          change1hPct: Number(t.change1hPct) || 0,
          change5mPct: Number(t.change5mPct) || 0,
          source: 'mock',
          fetchedAt: Date.now()
        });
      }
      return out;
    },
    /** Per-token failure is isolated: one bad token never stops the rest. */
    async fetchTokenPrices(mints) {
      if (fx.failAll) throw new Error('mock provider unavailable');
      const out = new Map();
      for (const mint of mints) {
        const t = fx.byMint.get(mint);
        if (!t) continue;
        try {
          if (t.fail) throw new Error(`mock fetch failure (${t.symbol})`);
          const baseSol = Number(t.priceSol) || 0;
          const priceSol = advance(mint) || baseSol;
          const now = Date.now();
          let ageMs = 0;
          if (t.staleAtBuy) ageMs = maxPriceAgeMs + 60000; // guarantee staleness
          const priceUsd = t.invalidAtBuy ? 0
            : (Number(t.priceUsd) || 0) * (baseSol ? priceSol / baseSol : 1);
          out.set(mint, {
            priceUsd,
            priceSol: t.invalidAtBuy ? 0 : priceSol,
            source: 'mock',
            timestamp: now - ageMs,
            ageMs
          });
        } catch (err) {
          // isolate per-token failures — continue with the remaining tokens
        }
      }
      return out;
    }
  };
}

/* ------------------------------------------------------------------ *
 * DexScreener provider (REAL market data).
 * ------------------------------------------------------------------ */

const DEXSCREENER_BASE = 'https://api.dexscreener.com';
const GECKOTERMINAL_BASE = 'https://api.geckoterminal.com/api/v2/networks/solana';
const MAX_DISCOVERY_MINTS = 90; // cap on merged discovery mints per scan

/**
 * Solana mint from a DexScreener token-profile / token-boost entry (else null).
 * Only real Solana entries pass: chainId must be 'solana' and the token
 * address must be a valid base58 Solana mint. Non-Solana entries are rejected
 * even when their address happens to look base58-like.
 */
function mintFromProfileEntry(p) {
  if (!p || p.chainId !== 'solana') return null;
  return isValidSolanaAddress(p.tokenAddress) ? p.tokenAddress : null;
}

/**
 * Solana mint from a GeckoTerminal relationship id, e.g. 'solana_<address>'.
 * Any non-Solana id ('ethereum_0x…', 'base_0x…', …) is rejected.
 */
function mintFromGeckoId(id) {
  if (typeof id !== 'string') return null;
  const at = id.indexOf('_');
  const addr = at >= 0 ? id.slice(at + 1) : id;
  return isValidSolanaAddress(addr) ? addr : null;
}

/** Solana mints (deduped, in order) from a GeckoTerminal pools response body. */
function mintsFromGeckoPools(body) {
  const pools = Array.isArray(body && body.data) ? body.data : [];
  const out = [];
  const seen = new Set();
  for (const pool of pools) {
    const rel = pool && pool.relationships && pool.relationships.base_token;
    const mint = mintFromGeckoId(rel && rel.data && rel.data.id);
    if (mint && !seen.has(mint)) { seen.add(mint); out.push(mint); }
  }
  return out;
}

function createDexProvider({ maxPriceAgeMs, solPriceCacheMs, onEvent }) {
  let solCache = null;      // { priceUsd, ts }
  let lastOkAt = null;
  let lastError = null;
  let requests = 0;
  let failures = 0;

  const noteOk = () => { lastOkAt = Date.now(); lastError = null; };
  const noteErr = (msg) => { lastError = msg; failures += 1; };
  const emit = (tag, msg) => { if (onEvent) onEvent(tag, msg); };

  async function getSolPriceUsd() {
    const now = Date.now();
    if (solCache && now - solCache.ts < solPriceCacheMs) return solCache;
    requests += 1;
    const data = await fetchJson(
      `${DEXSCREENER_BASE}/latest/dex/tokens/${WRAPPED_SOL_MINT}`,
      { timeoutMs: DEFAULT_TIMEOUT_MS, label: 'dex-sol-price' }
    );
    const pairs = Array.isArray(data.pairs) ? data.pairs : [];
    const solPair = pairs.find((p) =>
      p && p.baseToken && p.baseToken.address === WRAPPED_SOL_MINT && Number(p.priceUsd) > 0);
    if (!solPair) throw new Error('dex-sol-price: no SOL/USD pair in response');
    const priceUsd = Number(solPair.priceUsd);
    noteOk();
    solCache = { priceUsd, ts: now };
    return { priceUsd, priceSol: 1, source: 'dexscreener', timestamp: now, ageMs: 0 };
  }

  function candidateFromPair(pair) {
    const base = pair.baseToken;
    if (!base || !isValidSolanaAddress(base.address)) return null;
    const priceUsd = Number(pair.priceUsd);
    const priceNative = Number(pair.priceNative);
    const liquidityUsd = Number(pair.liquidity && pair.liquidity.usd) || 0;
    const volume24hUsd = Number(pair.volume && pair.volume.h24) || 0;
    const priceChange = pair.priceChange || {};
    if (!(priceUsd > 0)) return null;
    if (!(liquidityUsd > 0) || !(volume24hUsd > 0)) return null;
    const change1hPct = Number(priceChange.h1);
    const change5mPct = Number(priceChange.m5);
    if (!Number.isFinite(change1hPct) || !Number.isFinite(change5mPct)) return null;
    return {
      symbol: base.symbol || base.address.slice(0, 6),
      mint: base.address,
      priceUsd,
      priceSol: 0, // filled later via real SOL price
      priceNative,
      quoteToken: pair.quoteToken ? pair.quoteToken.address : null,
      liquidityUsd,
      volume24hUsd,
      change1hPct,
      change5mPct,
      source: 'dexscreener',
      fetchedAt: Date.now()
    };
  }

  /**
   * Discovery — merged multi-feed scan.
   *
   * Feeds (each isolated: one failing feed is logged and skipped, never the
   * whole scan):
   *   dex-profiles      newest token profiles      (DexScreener)
   *   dex-boosts        currently boosted tokens   (DexScreener)
   *   dex-boosts-top    top boosted tokens         (DexScreener)
   *   gt-trending       trending pools             (GeckoTerminal)
   *   gt-new            newly created pools        (GeckoTerminal)
   *
   * Feeds contribute Solana MINTS only. Every mint is then resolved through
   * the DexScreener pair batch endpoint, so all candidates share one real
   * price/liquidity/volume schema and one real SOL conversion. A mint without
   * usable DexScreener pair data is dropped — the engine never guesses a price
   * for an unknown pair. `via` records which feed(s) found each candidate.
   *
   * The scan only throws when every feed AND every pair resolution fails.
   */
  async function discoverCandidates() {
    const feeds = [
      { id: 'dex-profiles', url: `${DEXSCREENER_BASE}/token-profiles/latest/v1`, label: 'dex-profiles', extract: (b) => (Array.isArray(b) ? b : []).map(mintFromProfileEntry).filter(Boolean) },
      { id: 'dex-boosts', url: `${DEXSCREENER_BASE}/token-boosts/latest/v1`, label: 'dex-boosts', extract: (b) => (Array.isArray(b) ? b : []).map(mintFromProfileEntry).filter(Boolean) },
      { id: 'dex-boosts-top', url: `${DEXSCREENER_BASE}/token-boosts/top/v1`, label: 'dex-boosts-top', extract: (b) => (Array.isArray(b) ? b : []).map(mintFromProfileEntry).filter(Boolean) },
      { id: 'gt-trending', url: `${GECKOTERMINAL_BASE}/trending_pools?page=1`, label: 'gt-trending', extract: mintsFromGeckoPools },
      { id: 'gt-new', url: `${GECKOTERMINAL_BASE}/new_pools?page=1`, label: 'gt-new', extract: mintsFromGeckoPools }
    ];

    // 1. Gather mints from every feed, deduped, with feed attribution.
    const mints = [];
    const via = new Map(); // mint -> [feed ids]
    let feedFailures = 0;
    for (const feed of feeds) {
      requests += 1;
      let body;
      try {
        body = await fetchJson(feed.url, { timeoutMs: DEFAULT_TIMEOUT_MS, label: feed.label });
        noteOk();
      } catch (err) {
        noteErr(err.message);
        feedFailures += 1;
        emit('DISCOVERY-SKIP', `discovery feed ${feed.id} unavailable (${err.message}) — continuing with the others`);
        continue;
      }
      for (const mint of feed.extract(body)) {
        if (!via.has(mint)) { via.set(mint, []); mints.push(mint); }
        via.get(mint).push(feed.id);
      }
    }
    if (!mints.length) {
      if (feedFailures === feeds.length) throw new Error('all discovery feeds unavailable');
      return [];
    }
    const targets = mints.slice(0, MAX_DISCOVERY_MINTS);

    // 2. Resolve mints through the DexScreener pair batch endpoint (chunked,
    //    isolated — one failed chunk never stops the rest).
    const bestByMint = new Map();
    const chunks = [];
    for (let i = 0; i < targets.length; i += MAX_TOKENS_PER_REQUEST) {
      chunks.push(targets.slice(i, i + MAX_TOKENS_PER_REQUEST));
    }
    let chunkFailures = 0;
    for (const chunk of chunks) {
      requests += 1;
      let data;
      try {
        data = await fetchJson(`${DEXSCREENER_BASE}/latest/dex/tokens/${chunk.join(',')}`,
          { timeoutMs: DEFAULT_TIMEOUT_MS, label: 'dex-tokens' });
        noteOk();
      } catch (err) {
        noteErr(err.message);
        chunkFailures += 1;
        emit('DISCOVERY-SKIP', `pair resolution failed for ${chunk.length} mint(s) (${err.message}) — continuing`);
        continue;
      }
      const pairs = Array.isArray(data.pairs) ? data.pairs : [];
      for (const pair of pairs) {
        if (!pair || pair.chainId !== 'solana') continue;
        const cand = candidateFromPair(pair);
        if (!cand) continue;
        const prev = bestByMint.get(cand.mint);
        if (!prev || cand.liquidityUsd > prev.liquidityUsd) bestByMint.set(cand.mint, cand);
      }
    }
    if (!bestByMint.size) {
      if (chunkFailures === chunks.length) throw new Error('pair resolution failed for all discovery mints');
      return [];
    }

    // 3. Fill priceSol from the REAL SOL price; reject candidates we cannot.
    let solPriceUsd = null;
    try {
      solPriceUsd = (await getSolPriceUsd()).priceUsd;
    } catch (err) {
      emit('PRICE-FALLBACK', `SOL price unavailable (${err.message}) — using SOL-quoted priceNative where possible`);
    }

    const out = [];
    for (const cand of bestByMint.values()) {
      if (solPriceUsd) {
        cand.priceSol = cand.priceUsd / solPriceUsd;
      } else if (cand.quoteToken === WRAPPED_SOL_MINT && cand.priceNative > 0) {
        cand.priceSol = cand.priceNative;
      } else {
        continue; // no way to express this price in SOL → drop the candidate
      }
      cand.via = via.get(cand.mint).join('+');
      out.push(cand);
    }
    return out;
  }

  /**
   * Fetch current prices for many mints with bounded concurrency. Batch size
   * respects the API limit; one failed batch never stops the rest. Returns a
   * Map<mint, priceInfo>.
   */
  async function fetchTokenPrices(mints) {
    const sol = await getSolPriceUsd().catch(() => null);
    const out = new Map();
    const chunks = [];
    for (let i = 0; i < mints.length; i += MAX_TOKENS_PER_REQUEST) {
      chunks.push(mints.slice(i, i + MAX_TOKENS_PER_REQUEST));
    }
    const CONCURRENCY = 4;
    let cursor = 0;
    async function worker() {
      while (cursor < chunks.length) {
        const chunk = chunks[cursor++];
        requests += 1;
        let data;
        try {
          data = await fetchJson(`${DEXSCREENER_BASE}/latest/dex/tokens/${chunk.join(',')}`,
            { timeoutMs: DEFAULT_TIMEOUT_MS, label: 'dex-tokens' });
          noteOk();
        } catch (err) {
          noteErr(err.message);
          continue; // skip failed batch, keep sampling the rest
        }
        const pairs = Array.isArray(data.pairs) ? data.pairs : [];
        const byBase = new Map();
        for (const pair of pairs) {
          if (!pair || pair.chainId !== 'solana' || !pair.baseToken) continue;
          const cur = byBase.get(pair.baseToken.address);
          if (!cur || Number(pair.liquidity && pair.liquidity.usd) > Number(cur.liquidity && cur.liquidity.usd)) {
            byBase.set(pair.baseToken.address, pair);
          }
        }
        const now = Date.now();
        for (const mint of chunk) {
          const pair = byBase.get(mint);
          if (!pair) continue;
          const priceUsd = Number(pair.priceUsd);
          let priceSol = 0;
          if (sol && sol.priceUsd > 0) {
            priceSol = priceUsd / sol.priceUsd;
          } else if (pair.quoteToken && pair.quoteToken.address === WRAPPED_SOL_MINT) {
            priceSol = Number(pair.priceNative) || 0;
          } else {
            continue; // cannot express in SOL → skip
          }
          if (!(priceUsd > 0) || !(priceSol > 0)) continue;
          out.set(mint, {
            priceUsd,
            priceSol,
            source: 'dexscreener',
            timestamp: now,
            ageMs: 0
          });
        }
      }
    }
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, chunks.length) }, worker));
    return out;
  }

  return {
    name: 'dexscreener',
    label: 'dexscreener',
    getSolPriceUsd,
    discoverCandidates,
    fetchTokenPrices,
    stats() {
      return { requests, failures, lastOkAt, lastError };
    }
  };
}

/* ------------------------------------------------------------------ *
 * Circuit data API hook (optional PRIMARY).
 *
 * Activated by CIRCUIT_PRICE_API_URL. Expected contract (documented in
 * README): GET {base}/tokens/{mint} →
 *   { "priceUsd": 0.000123, "priceSol": 1.2e-6, "source": "circuit",
 *     "timestamp": 1720000000000 }
 * If a price field is missing it falls back to the other field via the real
 * SOL price. Any failure falls back to DexScreener automatically.
 * ------------------------------------------------------------------ */

function createCircuitProvider(apiBase, { onEvent }) {
  let lastOkAt = null;
  let lastError = null;
  let requests = 0;
  let failures = 0;
  const emit = (tag, msg) => { if (onEvent) onEvent(tag, msg); };

  return {
    name: 'circuit',
    label: 'circuit',
    async fetchTokenPrices(mints) {
      const out = new Map();
      const CONCURRENCY = 4;
      let cursor = 0;
      async function worker() {
        while (cursor < mints.length) {
          const mint = mints[cursor++];
          requests += 1;
          try {
            const body = await fetchJson(`${apiBase}/tokens/${mint}`,
              { timeoutMs: DEFAULT_TIMEOUT_MS, label: 'circuit-price' });
            const priceUsd = Number(body && body.priceUsd);
            const priceSol = Number(body && body.priceSol);
            const now = Date.now();
            if (priceUsd > 0 || priceSol > 0) {
              lastOkAt = now;
              lastError = null;
              out.set(mint, {
                priceUsd,
                priceSol,
                source: 'circuit',
                timestamp: now,
                ageMs: 0
              });
            } else {
              lastError = `circuit-price: no valid price for ${mint}`;
            }
          } catch (err) {
            lastError = err.message;
            failures += 1;
            emit('PRICE-FALLBACK', `Circuit price failed for ${mint} (${err.message}) — falling back to DexScreener`);
          }
        }
      }
      await Promise.all(Array.from({ length: Math.min(CONCURRENCY, mints.length) }, worker));
      return out;
    },
    stats() {
      return { requests, failures, lastOkAt, lastError };
    }
  };
}

/* ------------------------------------------------------------------ *
 * createMarketData — the one entry point.
 *
 * options:
 *   circuitApiUrl    optional CIRCUIT_PRICE_API_URL (becomes primary)
 *   mockFile         optional CIRCUIT_MOCK_MARKET_FILE (tests only)
 *   maxPriceAgeMs    staleness limit for trade decisions
 *   solPriceCacheMs  SOL price cache TTL
 *   onEvent          (tag, msg) callback for [PRICE-FALLBACK] style logs
 * ------------------------------------------------------------------ */

function createMarketData(options = {}) {
  const opts = Object.assign({
    circuitApiUrl: null,
    mockFile: null,
    maxPriceAgeMs: 60000,
    solPriceCacheMs: DEFAULT_SOL_PRICE_CACHE_MS,
    onEvent: null
  }, options);

  if (opts.mockFile) {
    return {
      mode: 'mock',
      primarySource: 'mock',
      fallbackSource: null,
      ...createMockProvider(opts.mockFile, { maxPriceAgeMs: opts.maxPriceAgeMs })
    };
  }

  const dex = createDexProvider({
    maxPriceAgeMs: opts.maxPriceAgeMs,
    solPriceCacheMs: opts.solPriceCacheMs,
    onEvent: opts.onEvent
  });

  if (opts.circuitApiUrl) {
    const circuit = createCircuitProvider(opts.circuitApiUrl, { onEvent: opts.onEvent });
    return {
      mode: 'real',
      primarySource: 'circuit',
      fallbackSource: 'dexscreener',
      async getSolPriceUsd() { return dex.getSolPriceUsd(); },
      /**
       * Primary = Circuit. Prices the Circuit API cannot provide are fetched
       * from DexScreener. When both provide a price, they are compared and
       * abnormally divergent prices are rejected (never silently substituted).
       */
      async fetchTokenPrices(mints) {
        const [circuitPrices, dexPrices] = await Promise.all([
          circuit.fetchTokenPrices(mints).catch(() => new Map()),
          dex.fetchTokenPrices(mints).catch(() => new Map())
        ]);
        const out = new Map();
        for (const mint of mints) {
          const c = circuitPrices.get(mint);
          const d = dexPrices.get(mint);
          if (c && d) {
            const cmp = comparePrices(c, d, opts.maxDivergencePct || 25);
            if (!cmp.ok) {
              if (opts.onEvent) {
                opts.onEvent('FILTER', `price divergence ${cmp.divergencePct}% for ${mint} — rejecting`);
              }
              continue;
            }
            out.set(mint, { source: 'circuit', ...c, priceSol: c.priceSol || d.priceSol });
          } else if (c) {
            out.set(mint, c);
          } else if (d) {
            if (opts.onEvent) {
              opts.onEvent('PRICE-FALLBACK', `Circuit price missing for ${mint} — using DexScreener`);
            }
            out.set(mint, d);
          }
        }
        return out;
      },
      async discoverCandidates() {
        // Discovery via DexScreener (Circuit has no discovery contract yet).
        return dex.discoverCandidates();
      },
      priceSources: () => [
        { name: 'circuit', role: 'primary', ...circuit.stats() },
        { name: 'dexscreener', role: 'fallback', ...dex.stats() }
      ]
    };
  }

  return {
    mode: 'real',
    primarySource: 'dexscreener',
    fallbackSource: null,
    getSolPriceUsd: dex.getSolPriceUsd,
    discoverCandidates: dex.discoverCandidates,
    fetchTokenPrices: dex.fetchTokenPrices,
    priceSources: () => [{ name: 'dexscreener', role: 'primary', ...dex.stats() }]
  };
}

module.exports = {
  createMarketData,
  isValidSolanaAddress,
  isValidPrice,
  priceAgeMs,
  comparePrices,
  mintFromProfileEntry,
  mintFromGeckoId,
  mintsFromGeckoPools,
  WRAPPED_SOL_MINT
};