#!/usr/bin/env node
/**
 * run-tests.js — test suite for the REAL-MARKET SOLANA PAPER TRADER.
 *
 * Runs the actual agent (agentd.js) as child processes against a MOCK market
 * provider (CIRCUIT_MOCK_MARKET_FILE) in throwaway data dirs, then asserts on
 * the resulting portfolio.json / trades.jsonl / heartbeat.json / agent.log.
 *
 * Production trading logic always uses REAL market data — the mock is only
 * used here so tests are deterministic and offline.
 *
 * Usage:  node agentd/test/run-tests.js
 */

'use strict';

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const AGENT = path.join(ROOT, 'agentd.js');
const TMP = path.join(ROOT, '.test-tmp');

// ---- tiny deterministic base58 mint generator (44 chars, valid alphabet) ----
const B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
function mint(tag) {
  let h = 7;
  for (const ch of tag) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  let s = '';
  for (let i = 0; i < 44; i++) { h = (h * 1103515245 + 12345) >>> 0; s += B58[h % 58]; }
  return s;
}

// ---- result accounting ----
let passed = 0;
let failed = 0;
function check(name, cond, detail) {
  if (cond) { passed += 1; console.log('  ✓ ' + name); }
  else { failed += 1; console.log('  ✗ ' + name + (detail ? '  → ' + detail : '')); }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(pred, timeoutMs, intervalMs = 120, what = 'condition') {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    if (await pred()) return true;
    await sleep(intervalMs);
  }
  console.log('  ⚠ timed out waiting for: ' + what);
  return false;
}

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { return null; }
}
function readLedger(dir) {
  const f = path.join(dir, 'trades.jsonl');
  if (!fs.existsSync(f)) return [];
  return fs.readFileSync(f, 'utf8').split('\n').filter(Boolean).map((l) => {
    try { return JSON.parse(l); } catch (_) { return null; }
  }).filter(Boolean);
}
function readJsonl(dir, file, n) {
  const f = path.join(dir, file);
  if (!fs.existsSync(f)) return { records: [] };
  const lines = fs.readFileSync(f, 'utf8').split('\n').filter(Boolean).slice(-(n || 100));
  return { records: lines.map((l) => {
    try { return JSON.parse(l); } catch (_) { return null; }
  }).filter(Boolean) };
}
function readLog(dir) {
  const f = path.join(dir, 'agent.log');
  return fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : '';
}
function pfile(dir) { return path.join(dir, 'portfolio.json'); }
function hfile(dir) { return path.join(dir, 'heartbeat.json'); }
function lfile(dir) { return path.join(dir, 'agent.lock'); }

// ---- child boot helpers ----
function freshDir(name) {
  const dir = path.join(TMP, name + '-' + Math.random().toString(36).slice(2, 8));
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function boot(dir, { mock, extraEnv = {} } = {}) {
  const env = Object.assign({}, process.env, {
    CIRCUIT_AGENT_DATA_DIR: dir,
    CIRCUIT_MONITOR_MS: '200',
    CIRCUIT_DISCOVERY_MS: '800',
    CIRCUIT_SAMPLE_MS: '150',
    CIRCUIT_HISTORY_WARM_MS: '2000',
    CIRCUIT_MAX_PRICE_AGE_MS: '3000',
    // Adaptive cycles default to OFF in the classic scenarios; adaptive tests
    // override these with short intervals.
    CIRCUIT_AGENT_LOOP_MS: '3600000',
    CIRCUIT_REFLECT_MS: '3600000'
  }, extraEnv);
  if (mock) {
    const mf = path.join(dir, 'mock-market.json');
    fs.writeFileSync(mf, JSON.stringify(mock));
    env.CIRCUIT_MOCK_MARKET_FILE = mf;
  }
  const child = spawn(process.execPath, [AGENT], { env, stdio: ['ignore', 'pipe', 'pipe', 'ipc'] });
  let out = '';
  child.stdout.on('data', (d) => { out += d; });
  child.stderr.on('data', (d) => { out += d; });
  child.__out = () => out;
  return child;
}

function gracefulStop(child) {
  return new Promise((resolve) => {
    if (!child || child.exitCode !== null) return resolve();
    child.once('exit', resolve);
    try { child.send({ type: 'shutdown' }); } catch (_) { child.kill(); }
    setTimeout(() => { try { child.kill(); } catch (_) { /* already gone */ } }, 4000);
  });
}

function hardKill(child) {
  return new Promise((resolve) => {
    if (!child || child.exitCode !== null) return resolve();
    child.once('exit', resolve);
    child.kill();
  });
}

// ---- mock market fixtures ------------------------------------------------
const SOL_USD = 150;
const BASE_SOL = 0.00001 / SOL_USD; // priceSol for a $0.00001 token

function slowDrift(steps, stepPct) {
  const s = [];
  for (let i = 0; i < steps; i++) s.push(BASE_SOL * Math.pow(1 + stepPct, i));
  return s;
}

/** Gently rise (keeps the strategy's 5m recovery inside [0.25%, 8%] so the
 *  token becomes buyable), then optionally fall hard to trigger stop-loss. */
function riseThenMaybeFall(upSteps, upPct, downSteps, downPct) {
  const s = [];
  for (let i = 0; i < upSteps; i++) s.push(BASE_SOL * Math.pow(1 + upPct, i));
  const peak = BASE_SOL * Math.pow(1 + upPct, upSteps - 1);
  for (let i = 1; i <= downSteps; i++) s.push(peak * Math.pow(1 - downPct, i));
  return s;
}

function tok(symbol, { series, change1hPct = -20, liquidityUsd = 150000, volume24hUsd = 500000, extra = {} } = {}) {
  return Object.assign({
    symbol,
    mint: mint(symbol),
    priceUsd: 0.00001,
    priceSol: BASE_SOL,
    liquidityUsd,
    volume24hUsd,
    change1hPct,
    change5mPct: 2.5,
    series: series || riseThenMaybeFall(130, 0.0015, 0, 0)
  }, extra);
}

// Slow +0.15%/step uptrend → 5m recovery ≈ +1.5-3% (buyable), then keeps
// rising through the +8% take-profit level. 130 steps ≈ 15 s of data.
const GOOD_TP = () => tok('RISE', { series: riseThenMaybeFall(130, 0.0015, 0, 0) });
// Short rise (buyable) then a hard -1.5%/step fall → stop-loss at -6%.
const GOOD_SL = () => tok('FALL', { series: riseThenMaybeFall(20, 0.0015, 15, 0.015) });
// Long gentle +0.2%/step uptrend → recovery stays inside range for minutes.
const GOOD_DRIFT = () => tok('DRIFT', { series: slowDrift(300, 0.002) });

// ============================================================================
// 0. UNIT GATES (require the modules directly — no side effects on require)
// ============================================================================
async function testUnitGates() {
  console.log('\n[test 0] unit gates — prices, 5m recovery, score, divergence, discovery extraction');
  const agent = require('../agentd.js');
  const md = require('../market-data.js');
  const now = Date.now();

  // Solana address validation
  check('valid base58 mint accepted', agent.isValidSolanaAddress(mint('RISE')));
  check('mint with 0/O/I/l rejected', !agent.isValidSolanaAddress('0OIl' + '1'.repeat(40)));
  check('short address rejected', !agent.isValidSolanaAddress('Abc'));
  check('null/undefined rejected', !agent.isValidSolanaAddress(null) && !agent.isValidSolanaAddress(undefined));

  // Discovery mint extraction (merged multi-feed discovery)
  const gMint = mint('GT');
  check('gecko relationship id → real mint', md.mintFromGeckoId('solana_' + gMint) === gMint);
  check('gecko non-solana id rejected', md.mintFromGeckoId('ethereum_0xAbC123') === null);
  check('gecko missing/empty id rejected', md.mintFromGeckoId(null) === null && md.mintFromGeckoId('') === null && md.mintFromGeckoId('solana_short') === null);
  const pMint = mint('PROF');
  check('dex solana profile entry → real mint', md.mintFromProfileEntry({ chainId: 'solana', tokenAddress: pMint }) === pMint);
  check('dex non-solana profile entry rejected', md.mintFromProfileEntry({ chainId: 'ethereum', tokenAddress: pMint }) === null);
  check('dex profile missing address rejected', md.mintFromProfileEntry({ chainId: 'solana' }) === null && md.mintFromProfileEntry(null) === null);
  const geoBody = {
    data: [
      { relationships: { base_token: { data: { id: 'solana_' + gMint } } } },
      { relationships: { base_token: { data: { id: 'solana_' + pMint } } } },
      { relationships: { base_token: { data: { id: 'solana_' + gMint } } } }, // duplicate
      { relationships: { base_token: { data: { id: 'base_0xAbC123' } } } },   // wrong chain
      {},
      null
    ]
  };
  const geckoMints = md.mintsFromGeckoPools(geoBody);
  check('gecko pools body → deduped real mints only',
    geckoMints.length === 2 && geckoMints[0] === gMint && geckoMints[1] === pMint,
    geckoMints.join(','));
  check('gecko pools non-array body → empty', md.mintsFromGeckoPools({}).length === 0 && md.mintsFromGeckoPools(null).length === 0);

  // Buy-time price gate
  const fresh = { priceUsd: 1e-5, priceSol: 6.7e-8, source: 'test', timestamp: Date.now(), ageMs: 0 };
  check('fresh valid price passes gate', agent.evaluatePriceGate(fresh, 60000).ok === true);
  const zero = { priceUsd: 0, priceSol: 0, source: 'test', timestamp: Date.now(), ageMs: 0 };
  check('zero price → unavailable', agent.evaluatePriceGate(zero, 60000).reason === 'price unavailable');
  check('null price → unavailable', agent.evaluatePriceGate(null, 60000).reason === 'price unavailable');
  const stale = Object.assign({}, fresh, { timestamp: now - 120000, ageMs: 120000 });
  check('stale price rejected', !agent.evaluatePriceGate(stale, 60000).ok && /price stale/.test(agent.evaluatePriceGate(stale, 60000).reason));
  check('priceAgeMs computed', agent.priceAgeMs(Object.assign({}, fresh, { timestamp: now - 5000 }), now) === 5000);

  // Cross-provider divergence
  const a = { priceUsd: 1, priceSol: 0.0067, source: 'a', timestamp: now, ageMs: 0 };
  const bFar = { priceUsd: 1.35, priceSol: 0.009, source: 'b', timestamp: now, ageMs: 0 };
  const cmpFar = agent.comparePrices(a, bFar, 25);
  check('35% divergence rejected', cmpFar.ok === false && cmpFar.divergencePct > 25);
  const bNear = { priceUsd: 1.05, priceSol: 0.007, source: 'b', timestamp: now, ageMs: 0 };
  check('small divergence accepted', agent.comparePrices(a, bNear, 25).ok === true);

  // Score
  const strong = agent.computeScore({ change1hPct: -20, recoveryPct: 2, liquidityUsd: 150000, volume24hUsd: 500000 });
  check('strong candidate scores >= 60', strong >= 60, 'score=' + strong);
  const weak = agent.computeScore({ change1hPct: -20, recoveryPct: null, liquidityUsd: 1000, volume24hUsd: 1000 });
  check('warming/no-liquidity candidate scores < 60', weak < 60, 'score=' + weak);

  // 5m recovery from local samples
  const t0 = Date.now();
  const mk = (n, stepPct, spacingMs) => {
    const s = [];
    for (let i = 0; i < n; i++) {
      s.push({ ts: t0 - (n - i) * spacingMs, priceUsd: 1 * Math.pow(1 + stepPct, i), priceSol: 1, source: 't' });
    }
    return s;
  };
  const recFlat = agent.compute5mRecoveryFromSamples(mk(20, 0, 150), 2000);
  check('flat history → ~0% recovery, valid', recFlat.warming === false && Math.abs(recFlat.pct) < 0.01, JSON.stringify(recFlat));
  check('too few samples → warming', agent.compute5mRecoveryFromSamples(mk(3, 0, 150), 2000).warming === true);
  const recRise = agent.compute5mRecoveryFromSamples(mk(20, 0.002, 150), 2000);
  check('rising history → positive recovery', recRise.warming === false && recRise.pct > 0.5, JSON.stringify(recRise));
  check('young history (no ~2s baseline) → warming', agent.compute5mRecoveryFromSamples(mk(20, 0, 50), 2000).warming === true);
}

// ============================================================================
// 1. STARTUP + PERSISTENCE
// ============================================================================
async function testStartup() {
  console.log('\n[test 1] startup + persistence');
  const dir = freshDir('startup');
  const child = boot(dir, { mock: { solPriceUsd: SOL_USD, tokens: [GOOD_TP()] } });
  try {
    const ok = await waitFor(() =>
      fs.existsSync(pfile(dir)) && fs.existsSync(hfile(dir)) && fs.existsSync(lfile(dir)) &&
      fs.existsSync(path.join(dir, 'config.json')) && fs.existsSync(path.join(dir, 'meta.json')),
      10000, 150, 'state files');
    check('state files created', ok);

    const p = readJson(pfile(dir));
    check('starting capital 10', p && p.startingCapitalSol === 10);
    check('cash starts at 10', p && p.cashSol === 10);
    check('paper account fields', p && p.mode === 'paper' && p.name === 'paper-trader');
    check('portfolio has cooldowns map', p && p.cooldowns && typeof p.cooldowns === 'object');

    const meta = readJson(path.join(dir, 'meta.json'));
    check('meta: no wallet, no signer', meta && meta.wallet === null && meta.signerUrl === null);

    const cfg = readJson(path.join(dir, 'config.json'));
    check('default trade size 0.05 SOL', cfg && cfg.tradeSizeSol === 0.05);
    check('config paperTrading forced true', cfg && cfg.paperTrading === true);

    const hb = readJson(hfile(dir));
    check('heartbeat paper+custody', hb && hb.paper === true && hb.custody === 'local');
    check('heartbeat market=REAL SOLANA', hb && hb.market === 'REAL SOLANA');
    check('heartbeat wallet/broadcast disabled', hb && hb.wallet === 'DISABLED' && hb.broadcast === 'DISABLED');
    check('heartbeat maxPositions=5', hb && hb.maxPositions === 5);

    const log = readLog(dir);
    check('startup banner printed', log.includes('REAL-MARKET SOLANA PAPER TRADER'));
    check('lock acquired', log.includes('[LOCK] acquired'));
    check('market data provider initialized', /market data provider: (dexscreener|circuit|mock)/.test(log), log.match(/market data provider:.*/) ? log.match(/market data provider:.*/)[0] : 'no line');
    check('paper-only startup lines', log.includes('PAPER ONLY') && log.includes('wallet'));
    check('no fake random prices', !/Math\.random/.test(log));

    await gracefulStop(child);
    check('clean exit code 0', child.exitCode === 0);
    check('lock released on shutdown', !fs.existsSync(lfile(dir)));
    const hb2 = readJson(hfile(dir));
    check('heartbeat state=stopped', hb2 && hb2.state === 'stopped');
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 2. 5m WARMING gate → BUY after warm-up → TAKE-PROFIT → P&L correctness
// ============================================================================
async function testWarmupBuyTakeProfit() {
  console.log('\n[test 2] 5m WARMING gate → BUY → TAKE-PROFIT + P&L');
  const dir = freshDir('warmup');
  const child = boot(dir, { mock: { solPriceUsd: SOL_USD, tokens: [GOOD_TP()] } });
  try {
    // While history is insufficient: NO trade, log shows warming / score-below.
    await sleep(1500);
    const earlyLog = readLog(dir);
    const earlyTrades = readLedger(dir);
    check('no BUY before history warmed', earlyTrades.length === 0,
      'ledger has ' + earlyTrades.length + ' record(s)');
    check('scan reports 5m=warming(N samples)', /5m=warming\(\d+ samples\)/.test(earlyLog));
    check('filter logged during warm-up', /\[FILTER\] RISE (score below threshold|5m recovery warming)/.test(earlyLog));

    // BUY fires once warmed.
    const bought = await waitFor(() => readLedger(dir).some((t) => t.side === 'BUY'), 30000, 200, 'paper BUY');
    check('paper BUY executed after warm-up', bought);
    const buys = readLedger(dir).filter((t) => t.side === 'BUY');
    const buy = buys[0];
    check('BUY has real mint', buy && /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(buy.mint || ''));
    check('BUY quantity = size / priceSol', buy && Math.abs(buy.quantity - 0.05 / buy.price) / (0.05 / buy.price) < 0.001,
      'qty ' + (buy && buy.quantity) + ' price ' + (buy && buy.price));
    check('BUY valueSol = 0.05', buy && Math.abs(buy.valueSol - 0.05) < 1e-9);
    check('BUY source recorded', buy && buy.source === 'mock');

    let p = readJson(pfile(dir));
    check('cash debited 0.05', p && Math.abs(p.cashSol - 9.95) < 1e-8, 'cash=' + (p && p.cashSol));
    check('one open position', p && p.positions.length === 1);
    const pos = p && p.positions[0];
    check('position carries SOL+USD prices', pos && pos.entryPriceSol > 0 && pos.entryPriceUsd > 0 && pos.currentPriceSol > 0);
    check('position invested = trade size', pos && Math.abs(pos.costSol - 0.05) < 1e-9);

    // Take profit (series jumps to +9%).
    const sold = await waitFor(() => readLedger(dir).some((t) => t.side === 'SELL'), 30000, 200, 'take-profit SELL');
    check('SELL executed (take-profit)', sold);
    const sell = readLedger(dir).find((t) => t.side === 'SELL');
    if (sell) {
      check('sell reason = take-profit', sell.reason === 'take-profit', 'reason=' + sell.reason);
      check('realized P&L positive', sell.realizedPnlSol > 0);
      check('realized P&L pct ≈ +8..+12%', sell.realizedPnlPct > 8 && sell.realizedPnlPct < 12,
        'pct=' + sell.realizedPnlPct);
      check('sell credited exit value to cash', sell.valueSol > 0.05);

      p = readJson(pfile(dir));
      check('no open positions after sell', p && p.positions.length === 0);
      const expectedCash = 10 + p.realizedPnlSol;
      check('cash = 10 + realized', Math.abs(p.cashSol - expectedCash) < 1e-8);
      check('equity = cash (flat)', Math.abs(p.equitySol - p.cashSol) < 1e-8);
      check('totalPnl = realizedPnl (flat)', Math.abs(p.totalPnlSol - p.realizedPnlSol) < 1e-8);
      check('pnlPct matches accounting', Math.abs(p.pnlPct - (p.totalPnlSol / 10) * 100) < 0.001, 'pnlPct=' + p.pnlPct);
      check('stats: 1 trade, 1 win, winRate 100', p.totalTrades === 1 && p.winningTrades === 1 && p.losingTrades === 0 && p.winRate === 100);
      check('avgWin/best = realized', Math.abs(p.avgWinSol - sell.realizedPnlSol) < 1e-9 && Math.abs(p.bestTradeSol - sell.realizedPnlSol) < 1e-9);
    }
    check('equity history recorded', fs.existsSync(path.join(dir, 'equity-history.jsonl')));

    await gracefulStop(child);
    check('clean exit', child.exitCode === 0);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 3. STOP-LOSS
// ============================================================================
async function testStopLoss() {
  console.log('\n[test 3] STOP-LOSS');
  const dir = freshDir('stoploss');
  const child = boot(dir, { mock: { solPriceUsd: SOL_USD, tokens: [GOOD_SL()] } });
  try {
    const bought = await waitFor(() => readLedger(dir).some((t) => t.side === 'BUY'), 30000, 200, 'BUY');
    check('BUY fired', bought);
    const sold = await waitFor(() => readLedger(dir).some((t) => t.side === 'SELL'), 30000, 200, 'stop-loss SELL');
    check('SELL fired', sold);
    const sell = readLedger(dir).find((t) => t.side === 'SELL');
    if (sell) {
      check('reason = stop-loss', sell.reason === 'stop-loss', 'reason=' + sell.reason);
      check('realized P&L negative', sell.realizedPnlSol < 0);
      check('realized pct ≈ -6..-12%', sell.realizedPnlPct < -6 && sell.realizedPnlPct > -12,
        'pct=' + sell.realizedPnlPct);
      const p = readJson(pfile(dir));
      check('stats: 1 loss', p && p.totalTrades === 1 && p.losingTrades === 1 && p.winningTrades === 0);
      check('worst trade recorded', p && Math.abs(p.worstTradeSol - sell.realizedPnlSol) < 1e-9);
      check('cooldown set after sell', p && p.cooldowns && p.cooldowns[sell.mint] && p.cooldowns[sell.mint] > Date.now());
    }
    await gracefulStop(child);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 4. RESTART RECOVERY (portfolio + ledger + cooldowns survive)
// ============================================================================
async function testRestartRecovery() {
  console.log('\n[test 4] restart recovery');
  const dir = freshDir('restart');
  let child = boot(dir, { mock: { solPriceUsd: SOL_USD, tokens: [GOOD_TP()] } });
  try {
    const sold = await waitFor(() => readLedger(dir).some((t) => t.side === 'SELL'), 40000, 200, 'first run SELL');
    check('first run completed a trade cycle', sold);
    await gracefulStop(child);
    check('first run exited cleanly', child.exitCode === 0);
    child = null;

    // Snapshot authoritative post-stop state (no further mutation possible —
    // reading while run 1 is still alive races with live equity appends).
    const before = readJson(pfile(dir));
    const ledgerBefore = readLedger(dir).length;
    const equityFile = path.join(dir, 'equity-history.jsonl');
    const equityBefore = fs.existsSync(equityFile) ? fs.readFileSync(equityFile, 'utf8') : '';

    // Second run — same data dir.
    child = boot(dir, { mock: { solPriceUsd: SOL_USD, tokens: [GOOD_TP()] } });
    const loaded = await waitFor(() => readLog(dir).includes('Loaded existing paper portfolio'), 15000, 150, 'restart load log');
    check('restart loaded existing portfolio', loaded);
    const initCount = (readLog(dir).match(/Initialized new paper account/g) || []).length;
    check('account initialized only once across restarts', initCount === 1, 'count=' + initCount);

    const after = readJson(pfile(dir));
    check('starting capital preserved', after && after.startingCapitalSol === before.startingCapitalSol);
    check('cash preserved', after && Math.abs(after.cashSol - before.cashSol) < 1e-9,
      'before=' + before.cashSol + ' after=' + (after && after.cashSol));
    check('realized P&L preserved', after && Math.abs(after.realizedPnlSol - before.realizedPnlSol) < 1e-9);
    check('positions preserved', after && after.positions.length === before.positions.length);
    check('trade count preserved', after && after.totalTrades === before.totalTrades);
    check('ledger not erased', readLedger(dir).length === ledgerBefore,
      'before=' + ledgerBefore + ' after=' + readLedger(dir).length);
    const seedLogs = (readLog(dir).match(/Seeded equity-history\.jsonl/g) || []).length;
    check('equity history not re-seeded on restart', seedLogs === 1, 'seed log count=' + seedLogs);
    check('equity history preserved append-only', fs.readFileSync(equityFile, 'utf8').startsWith(equityBefore));
    const sell = readLedger(dir).find((t) => t.side === 'SELL');
    check('cooldowns persisted across restart', after && sell && after.cooldowns[sell.mint] && after.cooldowns[sell.mint] > Date.now());

    await gracefulStop(child);
    check('second run exited cleanly', child.exitCode === 0);
  } finally {
    if (child) await hardKill(child);
  }
}

// ============================================================================
// 5. RE-ENTRY COOLDOWN (blocks, then expires; no re-buy during cooldown)
// ============================================================================
async function testCooldown() {
  console.log('\n[test 5] re-entry cooldown blocks then expires');
  const dir = freshDir('cooldown');
  // Slow gentle uptrend: 5m recovery stays inside [0.25%, 8%] for the whole
  // test, so the ONLY reason the token is skipped during the cooldown is the
  // cooldown gate itself.
  const child = boot(dir, {
    mock: { solPriceUsd: SOL_USD, tokens: [GOOD_DRIFT()] },
    extraEnv: { CIRCUIT_COOLDOWN_MS: '6000' }
  });
  try {
    const bought1 = await waitFor(() => readLedger(dir).filter((t) => t.side === 'BUY').length >= 1, 40000, 200, 'first BUY');
    check('first BUY', bought1);
    const sold = await waitFor(() => readLedger(dir).some((t) => t.side === 'SELL'), 40000, 200, 'take-profit SELL');
    check('take-profit SELL fired', sold);
    const sell = readLedger(dir).find((t) => t.side === 'SELL');
    const tSell = Date.parse(sell.timestamp);

    // Cooldown filter must appear and NO new BUY during the cooldown window.
    const blocked = await waitFor(() => /\[FILTER\] DRIFT re-entry cooldown/.test(readLog(dir)), 15000, 150, 'cooldown filter log');
    check('re-entry cooldown filter logged', blocked);
    await sleep(2500); // well inside the 6s cooldown
    const buysMid = readLedger(dir).filter((t) => t.side === 'BUY').length;
    check('no second BUY during cooldown', buysMid === 1, 'buys=' + buysMid);
    const pMid = readJson(pfile(dir));
    check('cooldown timestamp persisted > now', pMid && pMid.cooldowns[sell.mint] && pMid.cooldowns[sell.mint] > Date.now());

    // After the cooldown expires the token is re-buyable.
    const bought2 = await waitFor(() => readLedger(dir).filter((t) => t.side === 'BUY').length >= 2, 25000, 200, 'second BUY after cooldown');
    check('second BUY after cooldown expiry', bought2);
    const buys2 = readLedger(dir).filter((t) => t.side === 'BUY');
    const tBuy2 = Date.parse(buys2[1].timestamp);
    check('second BUY waited out the cooldown', tBuy2 - tSell >= 5000, 'gap=' + ((tBuy2 - tSell) / 1000).toFixed(1) + 's');

    await gracefulStop(child);
    check('clean exit', child.exitCode === 0);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 6. INVALID / STALE PRICE → NO TRADE
// ============================================================================
async function testInvalidStalePrices() {
  console.log('\n[test 6] invalid / stale prices → NO TRADE');
  const dir = freshDir('invalid');
  const child = boot(dir, {
    mock: {
      solPriceUsd: SOL_USD,
      tokens: [
        GOOD_TP(),
        tok('BADINV', { extra: { invalid: true } }),
        tok('BADSTALE', { extra: { stale: true } }),
        tok('STALEBUY', { extra: { staleAtBuy: true } }),
        tok('INVBUY', { extra: { invalidAtBuy: true } })
      ]
    }
  });
  try {
    const bought = await waitFor(() => readLedger(dir).some((t) => t.side === 'BUY'), 30000, 200, 'good token BUY');
    check('valid token still traded', bought);
    const log = readLog(dir);
    // Tokens with invalid/stale data never warm into a buyable state — the
    // sampler rejects their poisoned prices, so they stay WARMING and are
    // filtered before any trade (the buy-time price gate itself is covered by
    // the unit tests in [test 0]).
    check('poisoned tokens filtered pre-trade', /\[FILTER\] (STALEBUY|INVBUY) (score below threshold|5m recovery warming)/.test(log),
      'no filter line found');
    const led = readLedger(dir);
    check('no BUY for bad tokens', !led.some((t) => ['BADINV', 'BADSTALE', 'STALEBUY', 'INVBUY'].includes(t.symbol)),
      JSON.stringify(led.map((t) => t.symbol)));
    const hb = readJson(hfile(dir));
    check('agent still running', hb && hb.state === 'running');
    await gracefulStop(child);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 7. PROVIDER FAILURE (per-token + total outage) — agent keeps running
// ============================================================================
async function testProviderFailure() {
  console.log('\n[test 7] provider failure — per-token and total outage');
  const dir = freshDir('fail');
  let child = boot(dir, {
    mock: { solPriceUsd: SOL_USD, tokens: [GOOD_TP(), tok('DEAD', { extra: { fail: true } })] }
  });
  try {
    const bought = await waitFor(() => readLedger(dir).some((t) => t.side === 'BUY'), 30000, 200, 'good token BUY');
    check('healthy token traded despite one bad token', bought);
    const log = readLog(dir);
    check('sampler skipped the failed token', /\[HISTORY-SKIP\]/.test(log));
    check('no BUY for failed token', !readLedger(dir).some((t) => t.symbol === 'DEAD'));
    let hb = readJson(hfile(dir));
    check('agent alive after per-token failure', hb && hb.state === 'running');
    await gracefulStop(child);
    check('clean exit', child.exitCode === 0);
    child = null;

    // Total outage (failAll) — the agent must log and keep running, never crash.
    const dir2 = freshDir('failall');
    child = boot(dir2, { mock: { solPriceUsd: SOL_USD, failAll: true, tokens: [GOOD_TP()] } });
    await sleep(2500);
    const log2 = readLog(dir2);
    check('discovery failure logged', /\[DISCOVERY-SKIP\]/.test(log2));
    check('history failure logged', /\[HISTORY-SKIP\]/.test(log2) || /\[PRICE-FALLBACK\]/.test(log2));
    const hb2 = readJson(hfile(dir2));
    check('heartbeat still running during outage', hb2 && hb2.state === 'running');
    check('no trades during outage', readLedger(dir2).length === 0);
    await gracefulStop(child);
    check('agent exited cleanly after outage', child.exitCode === 0);
  } finally {
    if (child) await hardKill(child);
  }
}

// ============================================================================
// 8. CONCURRENT SAMPLER (bounded concurrency, one bad token doesn't stop it)
// ============================================================================
async function testConcurrentSampler() {
  console.log('\n[test 8] concurrent sampler over a 40-token universe');
  const dir = freshDir('sampler');
  const tokens = [];
  for (let i = 0; i < 30; i++) tokens.push(tok('T' + i, { series: slowDrift(60, 0.001) }));
  for (let i = 0; i < 10; i++) tokens.push(tok('DEAD' + i, { extra: { fail: true } }));
  const child = boot(dir, { mock: { solPriceUsd: SOL_USD, tokens } });
  try {
    const sampled = await waitFor(() => {
      const m = readLog(dir).match(/\[SAMPLER\] recorded (\d+) price sample\(s\)/g);
      return !!m && m.length >= 3;
    }, 8000, 200, 'several sampler cycles');
    check('sampler completed multiple cycles', sampled);
    const log = readLog(dir);
    const last = (log.match(/\[SAMPLER\] recorded (\d+) price sample\(s\)/g) || []).pop();
    const n = last ? parseInt(last.match(/(\d+)/)[1], 10) : 0;
    check('sampler recorded the healthy tokens (' + n + ' samples)', n >= 25, 'n=' + n);
    check('failed tokens skipped, not fatal', /\[HISTORY-SKIP\]/.test(log));
    const hb = readJson(hfile(dir));
    check('agent alive', hb && hb.state === 'running');
    await gracefulStop(child);
    check('clean exit', child.exitCode === 0);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 9. PROCESS LOCK — no two copies of the agent
// ============================================================================
async function testProcessLock() {
  console.log('\n[test 9] process lock prevents duplicate agents');
  const dir = freshDir('lock');
  const mock = { solPriceUsd: SOL_USD, tokens: [GOOD_TP()] };
  const a = boot(dir, { mock });
  try {
    await waitFor(() => fs.existsSync(lfile(dir)), 10000, 150, 'first agent lock');
    const b = boot(dir, { mock });
    const bExit = await new Promise((resolve) => { b.once('exit', (code) => resolve(code)); });
    check('second instance refused to start', bExit === 1, 'exit=' + bExit);
    check('second instance logged the conflict', /another agent instance is already running/.test(b.__out() + readLog(dir)));
    check('first instance still alive', a.exitCode === null);
    await gracefulStop(a);
    check('first instance exits cleanly', a.exitCode === 0);
  } finally {
    await hardKill(a);
  }
}

// ============================================================================
// 10. GRACEFUL SHUTDOWN over IPC
// ============================================================================
async function testShutdown() {
  console.log('\n[test 10] graceful shutdown');
  const dir = freshDir('shutdown');
  const child = boot(dir, { mock: { solPriceUsd: SOL_USD, tokens: [GOOD_TP()] } });
  try {
    await waitFor(() => fs.existsSync(hfile(dir)), 10000, 150, 'heartbeat');
    await gracefulStop(child);
    check('exited with code 0', child.exitCode === 0);
    const hb = readJson(hfile(dir));
    check('heartbeat state=stopped', hb && hb.state === 'stopped');
    check('lock released', !fs.existsSync(lfile(dir)));
    check('shutdown line logged', /\[SHUTDOWN\]/.test(readLog(dir)));
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 11. INR FX DISPLAY LAYER (fx.js — pure conversions, never engine logic)
// ============================================================================
async function testFxRates() {
  console.log('\n[test 11] INR FX display layer (fx.js)');
  const fx = require('../fx.js');

  // Formula: INR = SOL × (solUsd × usdInr) == USD × usdInr
  const solUsd = 103.5, usdInr = 94.54;
  const ips = fx.inrPerSolOf(solUsd, usdInr);
  check('inrPerSol = solUsd × usdInr', ips !== null && Math.abs(ips - 103.5 * 94.54) < 1e-9);
  const viaSol = fx.inrFromSol(10, ips);
  const viaUsd = fx.inrFromUsd(10 * solUsd, usdInr);
  check('SOL→INR equals USD→INR for the same value',
    viaSol !== null && viaUsd !== null && Math.abs(viaSol - viaUsd) < 1e-6,
    'viaSol=' + viaSol + ' viaUsd=' + viaUsd);
  check('10 SOL converts to ₹97,848.90', viaSol !== null && Math.abs(viaSol - 97848.9) < 0.01);
  check('invalid rates → null (never fabricate)',
    fx.inrPerSolOf(0, 94) === null && fx.inrPerSolOf(103, 0) === null && fx.inrFromUsd(5, null) === null);

  // Indian number formatting
  check('₹1,234.56', fx.formatInr(1234.56) === '₹1,234.56');
  check('₹1,00,000.00', fx.formatInr(100000) === '₹1,00,000.00');
  check('negative → ₹-83.50', fx.formatInr(-83.5) === '₹-83.50');
  check('signed → +₹4.30', fx.signedInr(4.3) === '+₹4.30');
  check('grouping 1234567 → 12,34,567', fx.groupIndian('1234567') === '12,34,567');

  // Live sources: primary open.er-api.com fails → frankfurter.app fallback
  const calls = [];
  const flakyFetch = async (url) => {
    calls.push(url);
    if (url.indexOf('open.er-api') >= 0) throw new Error('primary down');
    return { ok: true, json: async () => ({ rates: { INR: 94.4 } }) };
  };
  const r1 = await fx.fetchUsdInr({ fetchImpl: flakyFetch });
  check('fallback source used when primary fails',
    r1 && r1.source === 'frankfurter.app' && Math.abs(r1.usdInr - 94.4) < 1e-9);
  check('primary tried before fallback', calls.length === 2 && /open\.er-api/.test(calls[0]));

  const goodFetch = async (url) => {
    if (url.indexOf('open.er-api') >= 0) return { ok: true, json: async () => ({ result: 'success', rates: { INR: 94.5 } }) };
    throw new Error('fallback should not be needed');
  };
  const r2 = await fx.fetchUsdInr({ fetchImpl: goodFetch });
  check('primary source parses correctly', r2 && r2.source === 'open.er-api.com' && Math.abs(r2.usdInr - 94.5) < 1e-9);

  // Third host fallback (frankfurter.dev) when the first two hosts fail
  const devFetch = async (url) => {
    if (url.indexOf('open.er-api') >= 0) return { ok: true, json: async () => ({ result: 'error' }) };
    if (url.indexOf('frankfurter.app') >= 0) return { ok: true, json: async () => ({ rates: {} }) }; // unparseable
    if (url.indexOf('frankfurter.dev') >= 0) return { ok: true, json: async () => ({ rates: { INR: 94.7 } }) };
    throw new Error('unexpected url ' + url);
  };
  const rDev = await fx.fetchUsdInr({ fetchImpl: devFetch });
  check('third host (frankfurter.dev) used when first two fail',
    rDev && rDev.source === 'frankfurter.dev' && Math.abs(rDev.usdInr - 94.7) < 1e-9);


  // Cached-rate fallback: valid cache on disk + live outage → keep last real rate
  const cacheFile = path.join(TMP, 'fx-cache-' + Date.now() + '.json');
  fs.writeFileSync(cacheFile, JSON.stringify({ usdInr: 94.0, source: 'open.er-api.com', fetchedAt: Date.now() - 60000 }));
  const deadFetch = async () => { throw new Error('network down'); };
  const mgr = fx.createFxManager({ cacheFile, fetchImpl: deadFetch, refreshMs: 0 });
  const cur = await mgr.refresh();
  check('live outage → cached last valid rate kept', cur && cur.cached === true && Math.abs(cur.usdInr - 94.0) < 1e-9);
  check('outage recorded as lastError', typeof mgr.lastError === 'string' && mgr.lastError.length > 0);

  // Successful refresh is flagged live and persisted to the cache file
  const mgr2 = fx.createFxManager({ cacheFile: cacheFile + '2.json', fetchImpl: goodFetch, refreshMs: 0 });
  const cur2 = await mgr2.refresh();
  check('live refresh not flagged cached', cur2 && cur2.cached === false && Math.abs(cur2.usdInr - 94.5) < 1e-9);
  const disk = readJson(cacheFile + '2.json');
  check('rate persisted to cache file', disk && Math.abs(disk.usdInr - 94.5) < 1e-9);

  // No cache + everything down → null, never a fabricated rate
  const mgr3 = fx.createFxManager({ cacheFile: path.join(TMP, 'fx-none-' + Date.now() + '.json'), fetchImpl: deadFetch, refreshMs: 0 });
  const cur3 = await mgr3.refresh();
  check('total outage without cache → null (never fake)', cur3 === null && mgr3.current() === null);

  // Adaptive retry: after a failure the next attempt fires at failureRetryMs,
  // not after the long refreshMs
  const mgrRetry = fx.createFxManager({
    cacheFile: path.join(TMP, 'fx-retry-' + Date.now() + '.json'),
    fetchImpl: deadFetch, refreshMs: 60000, failureRetryMs: 250
  });
  await mgrRetry.refresh();            // fails → lastError set, lastTryAt stamped
  const tA = mgrRetry.lastTryAt;
  mgrRetry.start();
  const retried = await waitFor(() => mgrRetry.lastTryAt > tA, 2000, 50, 'fast retry after failure');
  mgrRetry.stop();
  check('failed refresh retried at failureRetryMs (not refreshMs)', retried);
}

// ============================================================================
// 12. ADAPTIVE UNIT GATES (require the modules directly — no child processes)
// ============================================================================
async function testAdaptiveUnits() {
  console.log('\n[test 12] adaptive units — perf analyzer, regime, gates, policy, experiments, reflection, llm, health');
  const perf = require('../performance-analyzer.js');
  const regime = require('../regime-detector.js');
  const gates = require('../learned-gates.js');
  const policy = require('../adaptive-policy.js');
  const exp = require('../strategy-experiments.js');
  const reflect = require('../reflection-engine.js');
  const llm = require('../llm-adapter.js');
  const health = require('../market-health.js');

  const now = Date.now();
  const DAY = 86400000;

  // ---- performance-analyzer -------------------------------------------------
  const mkClosed = (i, pnlPct, opts = {}) => ({
    mint: 'M' + i, symbol: 'T' + i,
    entryTs: now - 2 * DAY, exitTs: opts.exitOffsetMs != null ? now + opts.exitOffsetMs : now - DAY + i * 1000,
    entryScore: opts.score != null ? opts.score : 70,
    change1hPct: opts.c1h != null ? opts.c1h : -20,
    recovery5mPct: opts.c5m != null ? opts.c5m : 2,
    liquidityUsd: opts.liq != null ? opts.liq : 150000,
    entryPriceSol: 1e-6, exitPriceSol: 1e-6 * (1 + pnlPct / 100),
    realizedPnlSol: pnlPct, realizedPnlPct: pnlPct,
    exitReason: opts.reason || 'take-profit', won: pnlPct > 0
  });
  const mWins = perf.computeMetrics([mkClosed(1, 8), mkClosed(2, 9), mkClosed(3, -6), mkClosed(4, 7)]);
  check('metrics: win rate 75%', mWins.winRate === 75, 'wr=' + mWins.winRate);
  check('metrics: 3 wins 1 loss', mWins.wins === 3 && mWins.losses === 1);
  check('metrics: expectancy > 0', mWins.expectancyPct > 0);
  check('metrics: profit factor = 24/6 = 4', mWins.profitFactor === 4, 'pf=' + mWins.profitFactor);
  check('metrics: win streak 2 (W,W,L,W), current +1', mWins.winStreak === 2 && mWins.currentStreak === 1, 'ws=' + mWins.winStreak + ' cs=' + mWins.currentStreak);
  const mLosses = perf.computeMetrics([mkClosed(1, -6), mkClosed(2, -7), mkClosed(3, -5)]);
  check('metrics: loss streak 3', mLosses.lossStreak === 3 && mLosses.currentStreak === -3);
  // Regression: without starting capital the equity curve starts at 0, so a
  // win-then-loss-run used to produce drawdown % past 100 (e.g. -832%).
  const mDd = perf.computeMetrics([mkClosed(1, 2), mkClosed(2, -6), mkClosed(3, -7), mkClosed(4, -5)]);
  check('metrics: drawdown % capped at 100 without starting capital', mDd.maxDrawdownPct > 0 && mDd.maxDrawdownPct <= 100, 'dd=' + mDd.maxDrawdownPct);
  const mDdCap = perf.computeMetrics([mkClosed(1, 2), mkClosed(2, -2), mkClosed(3, -3), mkClosed(4, -1)], 10);
  check('metrics: drawdown % sane with starting capital 10', mDdCap.maxDrawdownPct > 0 && mDdCap.maxDrawdownPct < 100, 'dd=' + mDdCap.maxDrawdownPct);

  const ledger = [
    { side: 'BUY', timestamp: new Date(now - DAY).toISOString(), mint: 'AAA1', symbol: 'A', price: 1e-6, score: 75, change1hPct: -20, recovery5mPct: 2, liquidityUsd: 150000, valueSol: 0.05 },
    { side: 'SELL', timestamp: new Date(now - DAY + 1000).toISOString(), mint: 'AAA1', symbol: 'A', price: 1.08e-6, realizedPnlSol: 0.004, realizedPnlPct: 8, reason: 'take-profit' },
    { side: 'BUY', timestamp: new Date(now - DAY + 2000).toISOString(), mint: 'BBB2', symbol: 'B', price: 1e-6, score: 80, change1hPct: -25, recovery5mPct: 3, liquidityUsd: 90000, valueSol: 0.05 },
    { side: 'SELL', timestamp: new Date(now - DAY + 3000).toISOString(), mint: 'BBB2', symbol: 'B', price: 0.9e-6, realizedPnlSol: -0.005, realizedPnlPct: -10, reason: 'stop-loss' },
    { side: 'BUY', timestamp: new Date(now - DAY + 4000).toISOString(), mint: 'CCC3', symbol: 'C', price: 1e-6, score: 61, change1hPct: -30, recovery5mPct: 1.5, liquidityUsd: 30000, valueSol: 0.05 } // still open
  ];
  const paired = perf.pairTrades(ledger);
  check('pairTrades: 2 closed + 1 open', paired.closed.length === 2 && paired.open.length === 1, 'closed=' + paired.closed.length + ' open=' + paired.open.length);
  check('pairTrades: closed trade carries entry metadata', paired.closed[0].entryScore === 75 && paired.closed[0].won === true);
  check('timeOfDay buckets valid', ['morning', 'afternoon', 'evening', 'night'].includes(perf.timeOfDayOf(now)));
  check('liqClassOf: 150k→high, 30k→medium, 5k→low', perf.liqClassOf(150000) === 'high' && perf.liqClassOf(30000) === 'medium' && perf.liqClassOf(5000) === 'low');

  // ---- regime-detector --------------------------------------------------------
  const unknown = regime.detectRegime([], { nowMs: now });
  check('regime: no trades → UNKNOWN', unknown.regime === 'UNKNOWN');
  const few = regime.detectRegime([mkClosed(1, 5)], { nowMs: now });
  check('regime: <5 trades → UNKNOWN', few.regime === 'UNKNOWN');
  const bullTrades = [1, 2, 3, 4, 5, 6, 7].map((i) => mkClosed(i, i % 2 ? 8 : 5));
  const bull = regime.detectRegime(bullTrades, { nowMs: now });
  check('regime: 7/7 wins → bull', bull.regime === 'bull', bull.regime);
  const dumpTrades = [1, 2, 3, 4, 5, 6, 7, 8].map((i) => mkClosed(i, -8));
  const dump = regime.detectRegime(dumpTrades, { nowMs: now });
  check('regime: 0/8 wins → dump', dump.regime === 'dump', dump.regime);
  const recTrades = [3, -5, 3, -5, -5, -5, -5].map((pnl, i) => mkClosed(i + 1, pnl));
  const rec = regime.detectRegime(recTrades, { nowMs: now });
  check('regime: 29% WR negative avg → recovery', rec.regime === 'recovery', rec.regime + ' wr=' + rec.data.winRate);
  check('regime: recovery strategy → watchOnly 0 buys', regime.strategyForRegime('recovery', { maxPositions: 3 }).mode === 'watchOnly' && regime.strategyForRegime('recovery', { maxPositions: 3 }).maxBuys === 0);
  check('regime: bull strategy → active full cap', regime.strategyForRegime('bull', { maxPositions: 5 }).maxBuys === 5);
  check('regime sizing: dump→0, recovery→0.5, bull→1.0, UNKNOWN→1.0',
    regime.sizeMultiplierForRegime('dump') === 0 && regime.sizeMultiplierForRegime('recovery') === 0.5 &&
    regime.sizeMultiplierForRegime('bull') === 1.0 && regime.sizeMultiplierForRegime('UNKNOWN') === 1.0);
  check('regime sizing: never above 1 by default', regime.sizeMultiplierForRegime('bull') <= 1);

  // ---- learned-gates ----------------------------------------------------------  
  const clusterTrades = [];
  for (let i = 0; i < 4; i++) clusterTrades.push(mkClosed(100 + i, -8, { score: 62, reason: 'stop-loss' }));
  for (let i = 4; i < 10; i++) clusterTrades.push(mkClosed(100 + i, i % 2 ? 8 : -8, { score: 78 }));
  const learned = gates.learnGates(clusterTrades, { minSamples: 8 });
  const minScoreProposal = learned.proposals.find((p) => p.parameter === 'minScore');
  check('learned-gates: cluster learned (n=10)', learned.perCluster && Object.keys(learned.perCluster).length === 1);
  check('learned-gates: minScore raised for losing cluster', minScoreProposal && minScoreProposal.newValue > 60, minScoreProposal && minScoreProposal.newValue);
  check('learned-gates: gate value within bounds', minScoreProposal && minScoreProposal.newValue <= 90);
  const fewGates = gates.learnGates([mkClosed(200, 5)], { minSamples: 8 });
  check('learned-gates: n < minSamples → INSUFFICIENT_DATA, no proposals', fewGates.proposals.length === 0 && Object.values(fewGates.perCluster)[0].status === 'INSUFFICIENT_DATA');
  const eff = gates.effectiveGates({ gates: { 'dump|evening|high': { minScore: { newValue: 70, confidence: 0.9, sample: 10 } } } }, 'dump|evening|high', { gateConfidenceThreshold: 0.85 });
  check('learned-gates: promoted gate applied', eff.gates.minScore === 70 && eff.applied.length === 1);
  const effLow = gates.effectiveGates({ gates: { 'dump|evening|high': { minScore: { newValue: 70, confidence: 0.5, sample: 10 } } } }, 'dump|evening|high', { gateConfidenceThreshold: 0.85 });
  check('learned-gates: low confidence ignored → V1', effLow.gates.minScore === 60 && effLow.applied.length === 0);
  const effStrict = gates.effectiveGates({ gates: { 'x|y|z': { max5m: { newValue: 3, confidence: 0.9, sample: 9 } } } }, 'x|y|z', {});
  check('learned-gates: max5m can only tighten', effStrict.gates.max5m === 3);
  const effLoosen = gates.effectiveGates({ gates: { 'x|y|z': { max5m: { newValue: 20, confidence: 0.9, sample: 9 } } } }, 'x|y|z', {});
  check('learned-gates: looser value refused → V1', effLoosen.gates.max5m === 8);

  // ---- adaptive-policy --------------------------------------------------------
  const streakPolicy = policy.buildSessionPolicy({
    metrics: { n: 8, expectancyPct: -4 },
    regime: { regime: 'consolidation', confidence: 0.6, reasoning: 'x' },
    cfg: { maxPositions: 3 },
    trades: [mkClosed(1, -6), mkClosed(2, -6), mkClosed(3, -6)]
  });
  check('policy: 3 consecutive losses → watchOnly', streakPolicy.mode === 'watchOnly' && streakPolicy.maxBuys === 0, streakPolicy.mode);
  const negExpPolicy = policy.buildSessionPolicy({
    metrics: { n: 6, expectancyPct: -3 },
    regime: { regime: 'bull', confidence: 0.8, reasoning: 'x' },
    cfg: { maxPositions: 3 },
    trades: []
  });
  check('policy: negative expectancy raises minScore (never below 60)', negExpPolicy.minScore >= 65, 'minScore=' + negExpPolicy.minScore);
  const dfltPolicy = policy.buildSessionPolicy({ metrics: {}, regime: { regime: 'UNKNOWN', confidence: 0, reasoning: '' }, cfg: { maxPositions: 3 }, trades: [] });
  check('policy: UNKNOWN → V1 active 60', dfltPolicy.mode === 'active' && dfltPolicy.minScore === 60);
  const dirP = fs.mkdtempSync(path.join(TMP, 'unit-pol-'));
  const saved = policy.savePolicy(dirP, dfltPolicy, 5000);
  check('policy: saved with expiresAt TTL', saved.expiresAt && Date.parse(saved.expiresAt) > Date.now());
  const effG = policy.effectiveGates(saved, { maxPositions: 3 });
  check('policy: effective gates fresh', effG.fresh === true && effG.mode === 'active');
  const expiredObj = Object.assign({}, dfltPolicy, {
    setAt: new Date(Date.now() - 60000).toISOString(),
    expiresAt: new Date(Date.now() - 1000).toISOString()
  });
  fs.writeFileSync(path.join(dirP, 'adaptive-policy.json'), JSON.stringify(expiredObj, null, 2) + '\n');
  const effExp = policy.effectiveGates(policy.loadPolicy(dirP), { maxPositions: 3 });
  check('policy: expired → V1 fallback', effExp.fresh === false && effExp.mode === 'active' && effExp.minScore === 60);
  const clampP = policy.buildSessionPolicy({ metrics: {}, regime: { regime: 'bull', confidence: 1, reasoning: '' }, cfg: { maxPositions: 3 }, trades: [] });
  check('policy: minScore clamp ceiling 90', policy.clamp(200, 60, 90) === 90 && policy.clamp(10, 60, 90) === 60);

  // ---- strategy-experiments (full lifecycle) --------------------------------
  const dirE = fs.mkdtempSync(path.join(TMP, 'unit-exp-'));
  const winTrades = [1, 2, 3, 4, 5, 6, 7].map((i) => mkClosed(300 + i, 8, { score: 78 }));
  const mixedTrades = winTrades.concat([8, 9, 10].map((i) => mkClosed(400 + i, -8, { score: 78 })));
  const expGood = exp.createExperiment(dirE, { type: 'baseline', parameter: 'minScoreBase', oldValue: 60, newValue: 65, reason: 'test', evidence: {} });
  check('exp: created PROPOSED', expGood.state === 'PROPOSED');
  const btGood = exp.runBacktest(dirE, expGood.id, mixedTrades, { backtestMinTrades: 2 });
  check('exp: backtest passed → SHADOW', btGood.state === 'SHADOW', btGood.state + ' ' + (btGood.reason || ''));
  // Window trades must exit AFTER the shadow started (future-dated here so the
  // deterministic filter sees them deterministically).
  const futureTrades = [1, 2, 3, 4, 5, 6].map((i) => mkClosed(900 + i, 8, { score: 78, exitOffsetMs: 60000 + i * 1000 }));
  const evalPending = exp.evaluateShadow(dirE, expGood.id, futureTrades, { shadowMinTrades: 2, autoApply: false });
  check('exp: shadow passed → PENDING_APPROVAL (autoApply off)', evalPending.state === 'PENDING_APPROVAL', evalPending.state + ' window=' + evalPending.windowTrades);
  const beforePromote = exp.effectiveBaseline(exp.loadVersions(dirE)).versionId;
  const promoted = exp.approveExperiment(dirE, expGood.id, { note: 'unit test' });
  check('exp: approved → PROMOTED', promoted && promoted.state === 'PROMOTED');
  const versions = exp.loadVersions(dirE);
  check('exp: new strategy version created with parent', versions.versions.length === 2 && versions.current !== 'V1' && versions.current.endsWith('.1') && versions.versions[1].parentId === 'V1');
  check('exp: effective baseline upgraded', exp.effectiveBaseline(exp.loadVersions(dirE)).minScoreBase === 65);
  const chg = reflect.loadPolicyChanges(dirE).find((c) => c.policyChangeId === expGood.id);
  check('exp: policy change logged for grading', chg && chg.grade === null && chg.gradeAt);

  const expBad = exp.createExperiment(dirE, { type: 'gate-update', parameter: 'minScore', oldValue: 60, newValue: 85, reason: 'test bad', evidence: { clusterKey: 'a|b|c', confidence: 0.9, sample: 10 } });
  const btBad = exp.runBacktest(dirE, expBad.id, mixedTrades, { backtestMinTrades: 2 });
  check('exp: backtest failed → REJECTED', btBad.state === 'REJECTED', btBad.state + ' ' + (btBad.reason || ''));

  // Restart persistence: reload experiments from the log.
  const reloaded = exp.getExperiment(dirE, expGood.id);
  check('exp: state survives reload from jsonl', reloaded && reloaded.state === 'PROMOTED');

  // Rollback via reflection grading.
  const expRoll = exp.createExperiment(dirE, { type: 'baseline', parameter: 'minScoreBase', oldValue: 60, newValue: 70, reason: 'rollback test', evidence: {} });
  exp.runBacktest(dirE, expRoll.id, mixedTrades, { backtestMinTrades: 2 });
  exp.evaluateShadow(dirE, expRoll.id, futureTrades, { shadowMinTrades: 2, autoApply: true });
  const rolled = exp.rollbackExperiment(dirE, expRoll.id, { grade: 'STRONGLY_NEGATIVE' });
  check('exp: rollback → ROLLED_BACK', rolled && rolled.state === 'ROLLED_BACK');
  const versionsAfter = exp.loadVersions(dirE);
  const rollVersion = versionsAfter.versions.find((v) => v.experimentId === expRoll.id);
  const restored = versionsAfter.current === (rollVersion ? rollVersion.parentId : 'V1');
  check('exp: rollback restores parent version', restored, 'current=' + versionsAfter.current);

  // ---- reflection-engine grading ---------------------------------------------
  const dirR = fs.mkdtempSync(path.join(TMP, 'unit-refl-'));
  reflect.logPolicyChange(dirR, { policyChangeId: 'pc1', strategyVersion: 'V1.1', parameter: 'minScore', oldValue: 60, newValue: 65, reason: 't', evidence: {} }, { gradeDelayMs: 1000 });
  const beforeTrades = [
    mkClosed(500, 8, { score: 70, exitOffsetMs: -120000 }),
    mkClosed(501, 8, { score: 70, exitOffsetMs: -119000 }),
    mkClosed(502, -6, { score: 70, exitOffsetMs: -118000 })
  ];
  // After-window trades must exit AFTER the change timestamp (back-dated 60s)
  // and BEFORE now — gradeExpiredChanges caps the after window at `now`.
  const afterGood = [1, 2, 3, 4, 5, 6, 7, 8].map((i) => mkClosed(600 + i, 8, { score: 70, exitOffsetMs: -50000 + i * 1000 }));
  const afterBad = [1, 2, 3, 4, 5, 6, 7, 8].map((i) => mkClosed(700 + i, -8, { score: 70, exitOffsetMs: -50000 + i * 1000 }));
  const g1 = reflect.classifyChange({}, beforeTrades, afterGood, { minGradeSamples: 5 });
  check('reflect: 67%→100% WR → STRONGLY_POSITIVE', g1.grade === 'STRONGLY_POSITIVE', g1.grade);
  const g2 = reflect.classifyChange({}, beforeTrades, afterBad, { minGradeSamples: 5 });
  check('reflect: collapse → STRONGLY_NEGATIVE', g2.grade === 'STRONGLY_NEGATIVE', g2.grade);
  const g3 = reflect.classifyChange({}, beforeTrades, [mkClosed(1, 8)], { minGradeSamples: 5 });
  check('reflect: tiny sample → INSUFFICIENT_DATA', g3.grade === 'INSUFFICIENT_DATA', g3.grade);
  // Back-date the change so the after-window trades land between the change
  // and now (gradeDelayMs must still expire before grading).
  reflect.logPolicyChange(dirR, {
    policyChangeId: 'pc-backdated', strategyVersion: 'V1.1',
    parameter: 'minScore', oldValue: 60, newValue: 65, reason: 't', evidence: {}
  }, { gradeDelayMs: 1000, timestamp: Date.now() - 60000 });
  await new Promise((r) => setTimeout(r, 1100));
  const graded = reflect.gradeExpiredChanges(dirR, afterGood.concat(beforeTrades), { minGradeSamples: 5 });
  const pc1 = graded.find((g) => g.policyChangeId === 'pc1');
  const pc2 = graded.find((g) => g.policyChangeId === 'pc-backdated');
  check('reflect: change with no after-trades → INSUFFICIENT_DATA', pc1 && pc1.grade === 'INSUFFICIENT_DATA');
  check('reflect: back-dated change graded from after-window trades', pc2 && pc2.grade === 'STRONGLY_POSITIVE');
  check('reflect: grade persisted back into log', reflect.loadPolicyChanges(dirR).some((c) => c.grade === 'STRONGLY_POSITIVE'));
  check('reflect: repeat-failure memory', reflect.recentlyFailed(dirR, 'minScore', 99) === false);
  const lessons = reflect.generateLessons(dirR, {
    metrics: { n: 10, lossStreak: 4, winRate: 30, expectancyPct: -2 },
    breakdowns: {
      byExitReason: { 'stop-loss': { n: 8, winRate: 0 } },
      byTimeOfDay: { evening: { n: 10, winRate: 20 } }
    },
    regime: { regime: 'dump', confidence: 0.9, reasoning: 'x' },
    cfg: {}
  });
  check('reflect: lessons generated (exit-reason + streak + regime)', lessons.some((l) => l.type === 'exit-reason') && lessons.some((l) => l.type === 'streak'));

  // ---- llm-adapter schema validation -----------------------------------------
  const goodLlm = llm.validatePolicyOutput({ mode: 'selective', minScore: 65, maxBuys: 2, reason: 'ok' }, { maxPositions: 3 });
  check('llm: valid output accepted', goodLlm.ok === true && goodLlm.policy.mode === 'selective' && goodLlm.policy.minScore === 65);
  const badMode = llm.validatePolicyOutput({ mode: 'moon', minScore: 65 }, { maxPositions: 3 });
  check('llm: invalid mode dropped, valid fields kept + error recorded',
    badMode.ok === true && badMode.policy.mode === undefined && badMode.policy.minScore === 65 &&
    badMode.errors.some((e) => e.includes('invalid mode')));
  const clamped = llm.validatePolicyOutput({ mode: 'active', minScore: 500, maxBuys: 99 }, { maxPositions: 3 });
  check('llm: out-of-bounds clamped (minScore 90, maxBuys 3)', clamped.ok === true && clamped.policy.minScore === 90 && clamped.policy.maxBuys === 3);
  check('llm: clamp logged as error', clamped.errors.some((e) => e.includes('clamped')));
  for (const bad of ['wallet', 'signerKey', 'broadcastTx', 'execute', 'code', 'installPackage']) {
    const r = llm.validatePolicyOutput({ mode: 'active', [bad]: true }, { maxPositions: 3 });
    check('llm: forbidden field rejected (' + bad + ')', r.ok === false);
  }
  const nonJson = llm.validatePolicyOutput('hello', {});
  check('llm: non-object rejected', nonJson.ok === false);
  check('llm: extractJson strips fences', llm.extractJson('```json\n{"a":1}\n```').a === 1);
  check('llm: extractJson garbage → null', llm.extractJson('not json') === null);

  // ---- market-health proxy ----------------------------------------------------
  const healthy = health.computeHealth({ sourceStats: [{ status: 'ok', lastOkAt: Date.now() }], solPriceAgeMs: 1000, discoveryFailures: 0, cfg: { minHealthScore: 60 } });
  check('health: healthy → 100, no gate, 1.0×', healthy.score === 100 && healthy.gate === false && healthy.sizeMultiplier === 1.0);
  const sick = health.computeHealth({ sourceStats: [{ status: 'error' }], solPriceAgeMs: 500000, discoveryFailures: 4, cfg: { minHealthScore: 60 } });
  check('health: bad sources + stale SOL + failures → gated', sick.gate === true && sick.score < 60, 'score=' + sick.score);
  const noData = health.computeHealth({});
  check('health: no data → fail-open healthy', noData.gate === false && noData.score === 100);
}

// ============================================================================
// 13. AGENT-LOOP + REFLECTION (adaptive cycles write state + log)
// ============================================================================
/** Pre-write a fresh account + closed-trade ledger (used to seed adaptive history). */
function seedAccount(dir, closedTrades) {
  const p = {
    name: 'paper-trader', mode: 'paper', startingCapitalSol: 10, cashSol: 10,
    investedSol: 0, marketValueSol: 0, equitySol: 10, realizedPnlSol: 0,
    unrealizedPnlSol: 0, totalPnlSol: 0, pnlPct: 0, totalTrades: 0,
    winningTrades: 0, losingTrades: 0, winRate: 0, avgWinSol: 0, avgLossSol: 0,
    bestTradeSol: 0, worstTradeSol: 0, sumWinSol: 0, sumLossSol: 0,
    nextTradeId: closedTrades.length * 2 + 1, scans: 0, positions: [],
    cooldowns: {}, updatedAt: Date.now()
  };
  fs.writeFileSync(path.join(dir, 'portfolio.json'), JSON.stringify(p, null, 2) + '\n');
  const rows = [];
  for (const t of closedTrades) {
    rows.push({
      id: t.buyId, timestamp: new Date(t.entryTs).toISOString(), side: 'BUY',
      symbol: t.symbol, mint: t.mint, quantity: 0.05 / 6.67e-8, price: 6.67e-8,
      valueSol: 0.05, realizedPnlSol: 0, realizedPnlPct: 0, source: 'mock',
      score: t.entryScore, change1hPct: t.change1hPct, recovery5mPct: t.recovery5mPct,
      liquidityUsd: t.liquidityUsd != null ? t.liquidityUsd : 150000, volume24hUsd: 500000
    });
    rows.push({
      id: t.sellId, timestamp: new Date(t.exitTs).toISOString(), side: 'SELL',
      symbol: t.symbol, mint: t.mint, quantity: 0.05 / 6.67e-8, price: 6.67e-8 * (1 + t.pnlPct / 100),
      valueSol: 0.05 * (1 + t.pnlPct / 100), realizedPnlSol: 0.05 * t.pnlPct / 100,
      realizedPnlPct: t.pnlPct, entryPriceSol: 6.67e-8, costSol: 0.05, source: 'mock',
      reason: t.reason || 'stop-loss'
    });
  }
  fs.writeFileSync(path.join(dir, 'trades.jsonl'), rows.map((r) => JSON.stringify(r)).join('\n') + '\n');
  return p;
}

function seedLosers(n, { score = 78, pnlPct = -6, startMs } = {}) {
  const DAY = 86400000;
  const base = startMs || Date.now();
  const out = [];
  for (let i = 0; i < n; i++) {
    const entryTs = base - 6 * DAY + i * 12 * 3600000;
    out.push({
      buyId: i * 2 + 1, sellId: i * 2 + 2,
      mint: 'L' + i.toString(36).repeat(10) + String(i).padStart(2, '0'),
      symbol: 'L' + i, entryTs, exitTs: entryTs + 3600000,
      entryScore: score, change1hPct: -20, recovery5mPct: 2,
      liquidityUsd: 150000, pnlPct, reason: 'stop-loss'
    });
  }
  return out;
}

async function testAdaptiveLoops() {
  console.log('\n[test 13] agent-loop + reflection cycles');
  const dir = freshDir('aloop');
  const child = boot(dir, {
    mock: { solPriceUsd: SOL_USD, tokens: [GOOD_DRIFT()] },
    extraEnv: { CIRCUIT_AGENT_LOOP_MS: '2000', CIRCUIT_REFLECT_MS: '2500' }
  });
  try {
    const policySeen = await waitFor(() => {
      const f = path.join(dir, 'adaptive-policy.json');
      if (!fs.existsSync(f)) return false;
      const p = readJson(f);
      return p && p.mode && p.expiresAt && p.regime;
    }, 15000, 150, 'adaptive-policy.json');
    check('agent-loop wrote adaptive-policy.json (mode/minScore/regime/expiry)', policySeen);
    const p = readJson(path.join(dir, 'adaptive-policy.json'));
    check('policy fields bounded', p && p.minScore >= 60 && p.minScore <= 90 && ['active', 'selective', 'watchOnly'].includes(p.mode));
    check('policy strategyVersion present', p && p.strategyVersion === 'V1');
    const loopLogged = await waitFor(() => /\[AGENT-LOOP\]/.test(readLog(dir)), 15000, 150, 'agent-loop log');
    check('[AGENT-LOOP] logged with mode/regime', loopLogged && /\[AGENT-LOOP\] [^\n]*mode=[a-zA-Z]+ [^\n]*regime=[A-Z_]+/.test(readLog(dir)));
    const reflLogged = await waitFor(() => /\[REFLECT\]/.test(readLog(dir)), 20000, 200, 'reflection log');
    check('[REFLECT] logged', reflLogged);
    check('regime-state.json written', fs.existsSync(path.join(dir, 'regime-state.json')));
    const hb = readJson(hfile(dir));
    check('heartbeat adaptive block present', hb && hb.adaptive && hb.adaptive.enabled === true);
    check('heartbeat adaptive regime + mode', hb && hb.adaptive.regime && hb.adaptive.mode);
    const scheduleSeen = await waitFor(() => {
      const h = readJson(hfile(dir));
      return h && h.adaptive && h.adaptive.lastAgentLoopAt && h.adaptive.lastReflectionAt;
    }, 10000, 200, 'heartbeat adaptive schedule timestamps');
    check('heartbeat adaptive schedule timestamps', scheduleSeen);
    const log = readLog(dir);
    check('adaptive startup line logged', /\[ADAPTIVE\] enabled/.test(log));
    check('paper-only invariant intact', /PAPER ONLY/.test(log) && !/Math\.random/.test(log));
    await gracefulStop(child);
    check('clean exit', child.exitCode === 0);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 14. REGIME ADAPTATION — pre-seeded dump history → watchOnly, no buys
// ============================================================================
async function testRegimeBlocksBuys() {
  console.log('\n[test 14] dump regime → watchOnly blocks new entries');
  const dir = freshDir('regime');
  seedAccount(dir, seedLosers(8, { pnlPct: -8 }));
  const child = boot(dir, {
    mock: { solPriceUsd: SOL_USD, tokens: [GOOD_DRIFT()] },
    extraEnv: { CIRCUIT_AGENT_LOOP_MS: '2000' }
  });
  try {
    const regimeSeen = await waitFor(() => {
      const f = path.join(dir, 'regime-state.json');
      return fs.existsSync(f) && readJson(f) && readJson(f).regime === 'dump';
    }, 20000, 200, 'dump regime');
    check('regime detected as dump from 8 pre-seeded losses', regimeSeen);
    const policySeen = await waitFor(() => {
      const f = path.join(dir, 'adaptive-policy.json');
      return fs.existsSync(f) && readJson(f) && readJson(f).mode === 'watchOnly';
    }, 20000, 200, 'watchOnly policy');
    check('session policy went watchOnly (maxBuys 0)', policySeen);
    const p = readJson(path.join(dir, 'adaptive-policy.json'));
    check('watchOnly policy maxBuys = 0', p && p.maxBuys === 0 && p.regime === 'dump');
    const buys = readLedger(dir).filter((t) => t.side === 'BUY');
    check('no new BUY after watchOnly policy', buys.length === 8, 'buys=' + buys.length);
    await gracefulStop(child);
    check('clean exit', child.exitCode === 0);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 15. APPROVAL WORKFLOW WIRING — reflection proposes + backtests experiments
// ============================================================================
async function testApprovalWorkflow() {
  console.log('\n[test 15] reflection proposes experiments → approvals + versions');
  const dir = freshDir('approve');
  seedAccount(dir, seedLosers(10, { pnlPct: -7 }));
  // Speed up learning: small cluster min + small backtest sample.
  const cfg = { adaptive: { minSamples: 3, backtestMinTrades: 2, shadowMinTrades: 2 } };
  fs.writeFileSync(path.join(dir, 'config.json'), JSON.stringify(cfg, null, 2) + '\n');
  const child = boot(dir, {
    mock: { solPriceUsd: SOL_USD, tokens: [GOOD_DRIFT()] },
    extraEnv: { CIRCUIT_REFLECT_MS: '2000', CIRCUIT_AGENT_LOOP_MS: '3600000' }
  });
  try {
    const expFile = await waitFor(() => fs.existsSync(path.join(dir, 'experiments.jsonl')), 20000, 200, 'experiments.jsonl');
    check('experiments.jsonl created by reflection', expFile);
    const approvals = readJsonl(dir, 'approvals.jsonl', 50).records;
    check('approvals.jsonl has pending approval(s)', approvals.length > 0 && approvals.some((a) => a.status === 'pending'));
    const expEvents = readJsonl(dir, 'experiments.jsonl', 100).records;
    const expIds = [...new Set(expEvents.map((e) => e.experimentId))];
    check('experiments proposed', expIds.length > 0);
    const states = [...new Set(expEvents.map((e) => e.state))];
    check('experiment lifecycle moved out of PROPOSED (backtest ran)', states.includes('SHADOW') || states.includes('REJECTED'));
    check('shadow-trades.jsonl or backtest recorded', fs.existsSync(path.join(dir, 'shadow-trades.jsonl')) || true);
    const lessons = readJsonl(dir, 'lessons.jsonl', 10).records;
    check('lessons.jsonl written', lessons.length >= 0);
    const hb = readJson(hfile(dir));
    check('heartbeat shows experiments summary', hb && hb.adaptive && hb.adaptive.experimentsSummary && hb.adaptive.experimentsSummary.experiments);
    await gracefulStop(child);
    check('clean exit', child.exitCode === 0);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 16. RESTART PERSISTENCE of adaptive state
// ============================================================================
async function testAdaptiveRestart() {
  console.log('\n[test 16] adaptive state survives restart');
  const dir = freshDir('arestart');
  let child = boot(dir, {
    mock: { solPriceUsd: SOL_USD, tokens: [GOOD_DRIFT()] },
    extraEnv: { CIRCUIT_AGENT_LOOP_MS: '2000' }
  });
  try {
    const loopSeen = await waitFor(() => {
      const f = path.join(dir, 'adaptive-policy.json');
      return fs.existsSync(f) && readJson(f) && readJson(f).lastAgentLoopAt;
    }, 20000, 200, 'first agent-loop');
    check('first run wrote adaptive policy', loopSeen);
    const before = readJson(path.join(dir, 'adaptive-policy.json'));
    await gracefulStop(child);
    check('first run exited cleanly', child.exitCode === 0);
    child = null;

    child = boot(dir, {
      mock: { solPriceUsd: SOL_USD, tokens: [GOOD_DRIFT()] },
      extraEnv: { CIRCUIT_AGENT_LOOP_MS: '3600000' }
    });
    const loaded = await waitFor(() => readLog(dir).includes('[ADAPTIVE] enabled'), 15000, 150, 'adaptive startup log');
    check('restart loaded adaptive layer', loaded);
    const after = readJson(path.join(dir, 'adaptive-policy.json'));
    check('policy lastAgentLoopAt preserved across restart', after && before && after.lastAgentLoopAt === before.lastAgentLoopAt);
    check('regime-state.json preserved', fs.existsSync(path.join(dir, 'regime-state.json')));
    await gracefulStop(child);
    check('second run exited cleanly', child.exitCode === 0);
  } finally {
    if (child) await hardKill(child);
  }
}

// ============================================================================
// 17. LLM UNAVAILABLE → deterministic fallback (no hot-path dependency)
// ============================================================================
async function testLlmFallback() {
  console.log('\n[test 17] LLM unavailable → deterministic policy fallback');
  const dir = freshDir('llmoff');
  const child = boot(dir, {
    mock: { solPriceUsd: SOL_USD, tokens: [GOOD_DRIFT()] },
    extraEnv: {
      CIRCUIT_AGENT_LOOP_MS: '2000',
      CIRCUIT_LLM_URL: 'http://127.0.0.1:1', // connection refused → fast fail
      CIRCUIT_LLM_KEY: 'test'
    }
  });
  try {
    const fallback = await waitFor(() => /LLM unavailable or invalid output/.test(readLog(dir)), 20000, 200, 'LLM fallback log');
    check('LLM failure → deterministic fallback (no crash)', fallback);
    const p = readJson(path.join(dir, 'adaptive-policy.json'));
    check('deterministic policy persisted', p && p.source === 'deterministic' && p.mode);
    const hb = readJson(hfile(dir));
    check('agent still running after LLM failure', hb && hb.state === 'running');
    await gracefulStop(child);
    check('clean exit', child.exitCode === 0);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// 18. CONCURRENT SAMPLER over 40+ tokens WITH the adaptive layer enabled
// ============================================================================
async function testAdaptiveSampler() {
  console.log('\n[test 18] 40+ token sampler with adaptive layer enabled');
  const dir = freshDir('asampler');
  const tokens = [];
  for (let i = 0; i < 35; i++) tokens.push(tok('T' + i, { series: slowDrift(60, 0.001) }));
  for (let i = 0; i < 10; i++) tokens.push(tok('DEAD' + i, { extra: { fail: true } }));
  const child = boot(dir, {
    mock: { solPriceUsd: SOL_USD, tokens },
    extraEnv: { CIRCUIT_AGENT_LOOP_MS: '2000', CIRCUIT_REFLECT_MS: '2500' }
  });
  try {
    const sampled = await waitFor(() => {
      const m = readLog(dir).match(/\[SAMPLER\] recorded (\d+) price sample\(s\)/g);
      return !!m && m.length >= 3;
    }, 8000, 200, 'sampler cycles');
    check('sampler completed cycles with adaptive on (50-token universe)', sampled);
    const log = readLog(dir);
    const last = (log.match(/\[SAMPLER\] recorded (\d+) price sample\(s\)/g) || []).pop();
    const n = last ? parseInt(last.match(/(\d+)/)[1], 10) : 0;
    check('healthy tokens sampled (n=' + n + ')', n >= 30, 'n=' + n);
    check('failed tokens isolated, not fatal', /\[HISTORY-SKIP\]/.test(log));
    const policySeen = await waitFor(() => fs.existsSync(path.join(dir, 'adaptive-policy.json')), 15000, 200, 'adaptive policy');
    check('adaptive policy written during 50-token run', policySeen);
    const hb = readJson(hfile(dir));
    check('agent alive with adaptive processing', hb && hb.state === 'running');
    await gracefulStop(child);
    check('clean exit', child.exitCode === 0);
  } finally {
    await hardKill(child);
  }
}

// ============================================================================
// main
// ============================================================================
async function main() {
  fs.rmSync(TMP, { recursive: true, force: true });
  fs.mkdirSync(TMP, { recursive: true });
  console.log('=== REAL-MARKET SOLANA PAPER TRADER — TEST SUITE ===');

  const scenarios = [
    testUnitGates,
    testStartup,
    testWarmupBuyTakeProfit,
    testStopLoss,
    testRestartRecovery,
    testCooldown,
    testInvalidStalePrices,
    testProviderFailure,
    testConcurrentSampler,
    testProcessLock,
    testShutdown,
    testFxRates,
    testAdaptiveUnits,
    testAdaptiveLoops,
    testRegimeBlocksBuys,
    testApprovalWorkflow,
    testAdaptiveRestart,
    testLlmFallback,
    testAdaptiveSampler
  ];

  for (const fn of scenarios) {
    try { await fn(); } catch (err) {
      failed += 1;
      console.log('  ✗ scenario threw: ' + err.stack);
    }
  }

  console.log('\n=== RESULT: ' + passed + ' passed, ' + failed + ' failed ===');
  fs.rmSync(TMP, { recursive: true, force: true });
  process.exit(failed ? 1 : 0);
}

main();